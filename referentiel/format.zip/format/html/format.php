<?php 
// Based on default.php, included by ../import.php

class rformat_html extends rformat_default {

    function provide_export() {
      return true;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;
		global $USER; 
  		// get css bit
		$css_lines = file( "$CFG->dirroot/mod/referentiel/format/html/html.css" );
		$css = implode( ' ',$css_lines ); 
		$xp = "<html>\n";
  		$xp .= "<head>\n";
  		$xp .= "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />\n";
		$xp .= "<meta author=\"".referentiel_get_user_info($USER->id)."\">\n";
  		$xp .= "<title>Moodle Referentiel HTML Export</title>\n";
  		$xp .= $css;
  		$xp .= "</head>\n";
		$xp .= "<body>\n";
		$xp .= $content;
		$xp .= "</body>\n";
		$xp .= "</html>\n";

  		return $xp;
	}

	function export_file_extension() {
  		return "_h.html";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=60) {
        // insere un saut de ligne apres le 80 caracter 
		$s=$raw;
		$s1="";
		$s2="";
		$out="";
		$nbcar=strlen($s);
		while ($nbcar>$nmaxcar){
			$s1=substr( $s,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $s,0,$pos1);
				$s=substr( $s,$pos1+1);
			}
			else {
				$s1=substr( $s,0,$nmaxcar);
				$s=substr( $s,$nmaxcar);
			}
			$out.=$s1. " ";
			$nbcar=strlen($s);
		}
		$out.=$s;
		return $out;
    }

    /**
     * Turns item into an xml segment
     * @param item object
     * @return string xml segment
     */

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
            $code = $item->code_item;
            $description_item = $item->description_item;
            $ref_referentiel = $item->ref_referentiel;
            $ref_competence = $item->ref_competence;
			$type_item = $item->type_item;
			$poids_item = $item->poids_item;
			$num_item = $item->num_item;

            $expout .= "   <tr>\n";
			$expout .= "     <td class=\"item\"> ".stripslashes($code)."</td>\n";   
            $expout .= "     <td class=\"item\"> ".stripslashes($description_item)."</td>\n";
            // $expout .= "   <td class=\"item\"> $ref_referentiel</td>\n";
            // $expout .= "   <td class=\"item\"> $ref_competence</td>\n";
            $expout .= "     <td class=\"item\"> ".stripslashes($type_item)."</td>\n";
            $expout .= "     <td class=\"item\"> $poids_item</td>\n";
            $expout .= "     <td class=\"item\"> $num_item</td>\n";			
			$expout .= "   </tr>\n";   
        }
        return $expout;
    }

	 /**
     * Turns competence into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_competence( $competence ) {
    global $CFG;
        // initial string;
        $expout = "";
		
		if ($competence){
            $code = $competence->code_competence;
            $description_competence = $competence->description_competence;
            $ref_domaine = $competence->ref_domaine;
			$num_competence = $competence->num_competence;
			$nb_item_competences = $competence->nb_item_competences;
	    	
   			$expout .= "<table class='competence'>\n";
	        $expout .= "<tr>\n";
			$expout .= "    <th class=\"competence\"><b>".get_string('code_competence','referentiel')."</b></th>\n";   
   	        $expout .= "    <th class=\"competence\"><b>".get_string('description_competence','referentiel')."</b></th>\n";
       	    // $expout .= "    <th class=\"competence\"><b>".get_string('ref_domaine','referentiel')."</b></th>\n";
           	$expout .= "    <th class=\"competence\"><b>".get_string('num_competence','referentiel')."</b></th>\n";
            $expout .= "    <th class=\"competence\"><b>".get_string('nb_item_competences','referentiel')."</b></th>\n";
			$expout .= "</tr>\n";
			
			$expout .= "  <tr>\n";
			$expout .= "    <td class=\"competence\"> ".stripslashes($code)."</td>\n";   
            $expout .= "    <td class=\"competence\"> ".stripslashes($description_competence)."</td>\n";
            // $expout .= "  <td class=\"competence\"> $ref_domaine</td>\n";
            $expout .= "    <td class=\"competence\"> $num_competence</td>\n";
            $expout .= "    <td class=\"competence\"> $nb_item_competences</td>\n";
			$expout .= "  </tr>\n";
			$expout .= "</table>\n";

			// ITEM
			$compteur_item=0;
			$records_items = referentiel_get_item_competences($competence->id);
			
			if ($records_items){
				// DEBUG
				// echo "<br/>DEBUG :: ITEMS <br />\n";
				// print_r($records_items);
   				$expout .= "<table class='item'>\n";
	       	 	$expout .= "   <tr>\n";
				$expout .= "     <th class=\"item\"><b>".get_string('code','referentiel')."</b></th>\n";   
           		$expout .= "     <th class=\"item\"><b>".get_string('description_item','referentiel')."</b></th>\n";
		        // $expout .= "     <th class=\"item\"><b>".get_string('ref_referentiel','referentiel')."</b></th>\n";
    	   		// $expout .= "     <th class=\"item\"><b>".get_string('ref_competence','referentiel')."</b></th>\n";
	    	    $expout .= "     <th class=\"item\"><b>".get_string('type_item','referentiel')."</b></th>\n";
       			$expout .= "     <th class=\"item\"><b>".get_string('poids_item','referentiel')."</b></th>\n";
		        $expout .= "     <th class=\"item\"><b>".get_string('num_item','referentiel')."</b></th>\n";
				$expout .= "   </tr>\n"; 

				foreach ($records_items as $record_i){
					// DEBUG
					// echo "<br/>DEBUG :: ITEM <br />\n";
					// print_r($record_i);
					$expout .= $this->write_item( $record_i );
				}
				$expout .= "</table>\n";
			}
        }
        return $expout;
    }


	 /**
     * Turns domaine into an xml segment
     * @param domaine object
     * @return string xml segment
     */

    function write_domaine( $domaine ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
		
		if ($domaine){
            $code = $domaine->code_domaine;
            $description_domaine = $domaine->description_domaine;
            $ref_referentiel = $domaine->ref_referentiel;
			$num_domaine = $domaine->num_domaine;
			$nb_competences = $domaine->nb_competences;

			$expout .= "<br /><table class='domaine'>\n";
			$expout .= "<tr>\n";			
			$expout .= "   <th class=\"domaine\"><b>".get_string('code_domaine','referentiel')."</b></th>\n";   
		    $expout .= "   <th class=\"domaine\"><b>".get_string('description_domaine','referentiel')."</b></th>\n";
        	// $expout .= "   <th class=\"domaine\"><b>".get_string('ref_referentiel','referentiel')."</b></th>\n";
		    $expout .= "   <th class=\"domaine\"><b>".get_string('num_domaine','referentiel')."</b></th>\n";
	        $expout .= "   <th class=\"domaine\"><b>".get_string('nb_competences','referentiel')."</b></th>\n";
			$expout .= "</tr>\n";	
			
			$expout .= "<tr>\n";			
			$expout .= "   <td class=\"domaine\"> ".stripslashes($code)."</td>\n";   
            $expout .= "   <td class=\"domaine\"> ".stripslashes($description_domaine)."</td>\n";
            // $expout .= "   </td><td class=\"domaine\"> $ref_referentiel</td>\n";
            $expout .= "   <td class=\"domaine\"> $num_domaine</td>\n";
            $expout .= "   <td class=\"domaine\"> $nb_competences</td>\n";
			$expout .= "</tr>\n";
			$expout .= "</table>\n";
			
			// LISTE DES COMPETENCES DE CE DOMAINE
			$compteur_competence=0;
			$records_competences = referentiel_get_competences($domaine->id);
			if ($records_competences){
				// DEBUG
				// echo "<br/>DEBUG :: COMPETENCES <br />\n";
				// print_r($records_competences);
				foreach ($records_competences as $record_c){
					$expout .= $this->write_competence( $record_c );
				}
			}
        }
        return $expout;
    }



	 /**
     * Turns referentiel into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_referentiel( $referentiel ) {
    	global $CFG;
		global $USER;
        // initial string;
        $expout = "";
	    $id = $referentiel->id;

    	// add comment and div tags
    	$expout .= "<!-- date: ".date("Y/m/d")." referentiel:  $referentiel->id  name: ".stripslashes($referentiel->name)." -->\n";
    	// add header
    	$expout .= "<h3>".stripslashes($referentiel->name)."</h3>\n";
		
		if ($referentiel){
            $name = $referentiel->name;
            $code_referentiel = $referentiel->code_referentiel;
            $description_referentiel = $referentiel->description_referentiel;
            $url_referentiel = $referentiel->url_referentiel;
			$seuil_certificat = $referentiel->seuil_certificat;
			$timemodified = $referentiel->timemodified;			
			$nb_domaines = $referentiel->nb_domaines;
			$liste_codes_competence = $referentiel->liste_codes_competence;
			$liste_empreintes_competence = $referentiel->liste_empreintes_competence;
			$local = $referentiel->local;
			$logo_referentiel = $referentiel->logo_referentiel;
			
	    	$expout .= "<table class=\"referentiel\">\n";
			$expout .= "<tr>\n";
			$expout .= " <th class=\"referentiel\"><b>".get_string('name','referentiel')."</b></th>\n";
			$expout .= " <th class=\"referentiel\"><b>".get_string('code_referentiel','referentiel')."</b></th>\n";   
            $expout .= " <th class=\"referentiel\" colspan=\"2\"><b>".get_string('description_referentiel','referentiel')."</b></th>\n";
			$expout .= " </tr>\n";
			$expout .= "<tr>\n";
			$expout .= " <td class=\"referentiel\"> ".stripslashes($name)."</td>\n";
			$expout .= " <td class=\"referentiel\"> ".stripslashes($code_referentiel)."</td>\n";   
            $expout .= " <td class=\"referentiel\" colspan=\"2\"> ".stripslashes($description_referentiel)."</td>\n";
			$expout .= " </tr>\n";			
			$expout .= "<tr>\n";
			$expout .= "<tr>\n";
            $expout .= " <th class=\"referentiel\"><b>".get_string('url_referentiel','referentiel')."</b></th>\n";
            $expout .= " <th class=\"referentiel\"><b>".get_string('liste_codes_competence','referentiel')."</b></th>\n";
            $expout .= " <th class=\"referentiel\"><b>".get_string('seuil_certificat','referentiel')."</b></th>\n";
            $expout .= " <th class=\"referentiel\"><b>".get_string('nb_domaines','referentiel')."</b></th>\n";
            // $expout .= " <td class\"referentiel\"><b>".get_string('local','referentiel')."</b></td>\n";
			$expout .= "</tr>\n";			
            $expout .= " <td class=\"referentiel\"> <a href=\"".$url_referentiel."\" title=\"".$url_referentiel."\" target=\"_blank\">".$url_referentiel."</a></td>\n";
            $expout .= " <td class=\"referentiel\"> ".$this->write_ligne($liste_codes_competence,"/",60)."</td>\n";
            $expout .= " <td class=\"referentiel\"> ".$this->write_ligne($liste_empreintes_competence,"/",60)."</td>\n";
            $expout .= " <td class=\"referentiel\"> $seuil_certificat</td>\n";
            $expout .= " <td class=\"referentiel\"> $nb_domaines</td>\n";
            // $expout .= " <td class\"referentiel\"> $local</td>\n";
			$expout .= " <td class\"referentiel\"> $logo_referentiel</td>\n";
			$expout .= "</tr>\n";
			$expout .= "</table>\n\n\n";
			
			// DOMAINES
			if (isset($referentiel->id) && ($referentiel->id>0)){
				// LISTE DES DOMAINES
				$compteur_domaine=0;
				$records_domaine = referentiel_get_domaines($referentiel->id);
		    	if ($records_domaine){
    				// afficher
					// DEBUG
					// echo "<br/>DEBUG ::<br />\n";
					// print_r($records_domaine);
					foreach ($records_domaine as $record_d){
						// DEBUG
						// echo "<br/>DEBUG ::<br />\n";
						// print_r($records_domaine);
						$expout .= $this->write_domaine( $record_d );
					}
				}
			} 
		}
        return $expout;
    }
}

/**********************************************************************
***********************************************************************
									ACTIVITES
***********************************************************************
**********************************************************************/


// ACTIVITES : export des activites
class aformat_html extends aformat_default {

    function provide_export() {
      return true;
    }

	function provide_import() {
        return false;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;

  		// get css bit
		$css_lines = file( "$CFG->dirroot/mod/referentiel/format/xhtml/xhtml.css" );
		$css = implode( ' ',$css_lines ); 
		$xp =  "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n";
		$xp .= "  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n";
		$xp .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
  		$xp .= "<head>\n";
  		$xp .= "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />\n";
  		$xp .= "<title>Moodle Referentiel :: Activite XHTML Export</title>\n";
  		$xp .= $css;
  		$xp .= "</head>\n";
		$xp .= "<body>\n";
		$xp .= $content;
		$xp .= "</body>\n";
		$xp .= "</html>\n";

  		return $xp;
	}

	function export_file_extension() {
  		return "_h.html";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caracter 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }

    /**
     * Turns item into an xml segment
     * @param item object
     * @return string xml segment
     */

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- item: $item->id  -->
<table class='item'>\n";
		// 
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
            $code = $item->code_item;
            $description_item = $item->description_item;
            $ref_referentiel = $item->ref_referentiel;
            $ref_competence = $item->ref_competence;
			$type_item = $item->type_item;
			$poids_item = $item->poids_item;
			$num_item = $item->num_item;
            $expout .= "   <tr>\n";
			$expout .= "     <td><b>".get_string('code','referentiel')."</b></td><td> $code</td>\n";   
            $expout .= "     <td><b>".get_string('description_item','referentiel')."</b></td><td> $description_item</td>\n";
            $expout .= "     <td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= "     <td><b>".get_string('ref_competence','referentiel')."</b></td><td> $ref_competence</td>\n";
            $expout .= "     <td><b>".get_string('type_item','referentiel')."</b></td><td> $type_item</td>\n";
            $expout .= "     <td><b>".get_string('poids_item','referentiel')."</b></td><td> $poids_item</td>\n";
            $expout .= "     <td><b>".get_string('num_item','referentiel')."</b></td><td> $num_item</td>\n";			
			$expout .= "   </tr>\n";   
        }
		$expout .= "</table>\n";
        return $expout;
    }

	 /**
     * Turns document into an xml segment
     * @param document object
     * @return string xml segment
     */

    function write_document( $document ) {
    global $CFG;
       // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- document: $document->id  -->
<table class='item'>\n";
		if ($document){
			$id = $document->id ;		
            $type_document = trim($document->type_document);
            $description_document = trim($document->description_document);
			$url_document = $document->url_document;
            $ref_activite = $document->ref_activite;
            $expout .= "   <tr>\n";
            $expout .= "     <td><b>".get_string('type_document','referentiel')."</b></td><td> $type_document</td>\n";   
            $expout .= "     <td><b>".get_string('description_document','referentiel')."</b></td><td> $description_document</td>\n";
            $expout .= "     <td><b>".get_string('url_document','referentiel')."</b></td><td> $url_document</td>\n";
            $expout .= "     <td><b>".get_string('ref_activite','referentiel')."</b></td><td> $ref_activite</td>\n";
			$expout .= "   </tr>\n";   
        }
		$expout .= "</table>\n";
        return $expout;
    }

    /**
     * Turns activite into an xml segment
     * @param activite object
     * @return string xml segment
     */

    function write_activite( $activite ) {
    global $CFG;
       // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- activite: $activite->id  -->
<table class='competence'>\n";
		// 
		if ($activite){
			// DEBUG
			// echo "<br />\n";
			// print_r($activite);
			$id = $activite->id;
            $type_activite = trim($activite->type_activite);
            $description_activite = trim($activite->description_activite);
            $competences_activite = trim($activite->competences_activite);
            $commentaire_activite = trim($activite->commentaire_activite);
            $ref_instance = $activite->ref_instance;
            $ref_referentiel = $activite->ref_referentiel;
            $ref_course = $activite->ref_course;
			$userid = trim($activite->userid);
			$teacherid = $activite->teacherid;
			$date_creation = $activite->date_creation;
			$date_modif = $activite->date_modif;
			$approved = $activite->approved;
			
            $expout .= "<tr>\n";
            $expout .= "<td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= "<td><b>".get_string('type_activite','referentiel')."</b></td><td> $type_activite</td>\n";
            $expout .= "<td><b>".get_string('description_activite','referentiel')."</b></td><td> $description_activite</td>\n";
            $expout .= "<td><b>".get_string('competences_activite','referentiel')."</b></td><td> $competences_activite</td>\n";
            $expout .= "<td><b>".get_string('commentaire_activite','referentiel')."</b></td><td> $commentaire_activite</td>\n";
            $expout .= "<td><b>".get_string('ref_instance','referentiel')."</b></td><td> $ref_instance</td>\n";
            $expout .= "<td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= "<td><b>".get_string('ref_course','referentiel')."</b></td><td> $ref_course</td>\n";
            $expout .= "<td><b>".get_string('userid','referentiel')."</b></td><td> $userid</td>\n";
            $expout .= "<td><b>".get_string('teacherid','referentiel')."</b></td><td> $teacherid</td>\n";
            $expout .= "<td><b>".get_string('date_creation','referentiel')."</b></td><td> $date_creation</td>\n";
            $expout .= "<td><b>".get_string('date_modif','referentiel')."</b></td><td> $date_modif</td>\n";
            $expout .= "<td><b>".get_string('approved','referentiel')."</b></td><td> $approved</td>\n";
			
			// DOCUMENTS
			$records_documents = referentiel_get_documents($activite->id);
			
			if ($records_documents){
				foreach ($records_documents as $record_d){
					$expout .= $this->write_document( $record_d );
				}
			}
		}	
		$expout .= "</table>\n";
        return $expout;
    }

	
	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
	    $id = $referentiel_instance->id;

    	// add comment and div tags
    	$expout .= "<!-- certification :  $referentiel_instance->id  name: $referentiel_instance->name -->\n";
    	$expout .= "<table class=\"referentiel\">\n";

    	// add header
    	$expout .= "<h3>$referentiel_instance->name</h3>\n";
		// 
		$expout .= "<tr>\n";
		// 
		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = trim($referentiel_instance->name);
            $description_instance = trim($referentiel_instance->description_instance);
            $label_domaine = trim($referentiel_instance->label_domaine);
            $label_competence = trim($referentiel_instance->label_competence);
            $label_item = trim($referentiel_instance->label_item);
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;

			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= " <td><b>".get_string('name','referentiel')."</b></td><td> $name</td>\n";
			$expout .= " <td><b>".get_string('description_instance','referentiel')."</b></td><td> description_instance</td>\n";   
            $expout .= " <td><b>".get_string('label_domaine','referentiel')."</b></td><td> $label_domaine</td>\n";
            $expout .= " <td><b>".get_string('label_competence','referentiel')."</b></td><td> $label_competence</td>\n";
            $expout .= " <td><b>".get_string('label_item','referentiel')."</b></td><td> $label_item</td>\n";			
            $expout .= " <td><b>".get_string('date_instance','referentiel')."</b></td><td> $date_instance</td>\n";
            $expout .= " <td><b>".get_string('course')."</b></td><td> $course</td>\n";
            $expout .= " <td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= " <td><b>".get_string('visible','referentiel')."</b></td><td> $visible</td>\n";
			
			// ACTIVITES
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				$records_activites = referentiel_get_activites($referentiel_instance->ref_referentiel);
		    	if ($records_activites){
					foreach ($records_activites as $record_a){
						// DEBUG
						// print_r($record_a);
						// echo "<br />\n";
						$expout .= $this->write_activite( $record_a );
					}
				}
			}
        }
        return $expout;
    }
}

// ACTIVITES : export des certificats
class cformat_html extends cformat_default {

    function provide_export() {
      return true;
    }

	function provide_import() {
        return false;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;

  		// get css bit
		$css_lines = file( "$CFG->dirroot/mod/referentiel/format/xhtml/xhtml.css" );
		$css = implode( ' ',$css_lines ); 
		$xp =  "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n";
		$xp .= "  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n";
		$xp .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
  		$xp .= "<head>\n";
  		$xp .= "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />\n";
  		$xp .= "<title>Moodle Referentiel :: Certificats XHTML Export</title>\n";
  		$xp .= $css;
  		$xp .= "</head>\n";
		$xp .= "<body>\n";
		$xp .= $content;
		$xp .= "</body>\n";
		$xp .= "</html>\n";

  		return $xp;
	}

	function export_file_extension() {
  		return "_h.html";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caracter 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }


		function write_etablissement( $record ) {
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- etablissement: $record->id  -->\n";
		if ($record){
    		$expout .= "<table class=\"referentiel\">\n";
			$expout .= "<h4>".get_string('etablissement','referentiel')."</h4>\n";
			// 
			
			$expout .= "<tr>\n";		// 
			$id = trim( $record->id );
			$num_etablissement = trim( $record->num_etablissement);
			$nom_etablissement = trim( $record->nom_etablissement);
			$adresse_etablissement = trim( $record->adresse_etablissement);
			$logo = trim( $record->logo_etablissement);
						
			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
            $expout .= " <td><b>".get_string('num_etablissement','referentiel')."</b></td><td> $num_etablissement</td>\n";
            $expout .= " <td><b>".get_string('nom_etablissement','referentiel')."</b></td><td> $nom_etablissement</td>\n";			
            $expout .= " <td><b>".get_string('adresse_etablissement','referentiel')."</b></td><td> $adresse_etablissement</td>\n";
            $expout .= " <td><b>".get_string('logo','referentiel')."</b></td><td> $logo</td>\n";			
			$expout .= " </tr>\n";
			$expout .= "</table>\n\n";		//			
        }
        return $expout;
    }


	
	function write_etudiant( $record ) {
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- etudiant: $record->id  -->\n";
		if ($record){
			// DEBUG
			// echo "<br />\n";
			// print_r($record);
	    	// add header
			$expout .= "<table class=\"referentiel\">\n";
			
    		$expout .= "<h4>Etudiant</h4>\n";
			// 
			$expout .= "<tr>\n";		// 
			
			$id = trim( $record->id );
			$userid = trim( $record->userid );
            $ref_etablissement = trim( $record->ref_etablissement);
			$num_etudiant = trim( $record->num_etudiant);
			$ddn_etudiant = trim( $record->ddn_etudiant);
			$lieu_naissance = trim( $record->lieu_naissance);
			$departement_naissance = trim( $record->departement_naissance);
			$adresse_etudiant = trim( $record->adresse_etudiant);			

			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= " <td><b>".get_string('userid','referentiel')."</b></td><td> $userid</td>\n";	
			$expout .= " <td><b>".get_string('nom_prenom','referentiel')."</b></td><td> ".referentiel_get_user_info($record->userid)."</td>\n";
			$expout .= " <td><b>".get_string('num_etudiant','referentiel')."</b></td><td> $num_etudiant</td>\n";
            $expout .= " <td><b>".get_string('ddn_etudiant','referentiel')."</b></td><td> $ddn_etudiant</td>\n";
            $expout .= " <td><b>".get_string('lieu_naissance','referentiel')."</b></td><td> $lieu_naissance</td>\n";
            $expout .= " <td><b>".get_string('departement_naissance','referentiel')."</b></td><td> $departement_naissance</td>\n";			
            $expout .= " <td><b>".get_string('adresse_etudiant','referentiel')."</b></td><td> $adresse_etudiant</td>\n";
			$expout .= " <td><b>".get_string('ref_etablissement','referentiel')."</b></td><td> $ref_etablissement</td>\n";
			// Etablissement
			$record_etablissement=referentiel_get_etablissement($record->ref_etablissement);
	    	if ($record_etablissement){
				$expout .= $this->write_etablissement( $record_etablissement );
			}
		    $expout .= " </tr>\n";
			$expout .= "</table>\n\n";		//			
        }
        return $expout;
    }

	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certificat( $record ) {
    	global $CFG;
        // initial string;
        $expout = "";
    	// add comment and div tags
    	$expout .= "<!-- certification :  $record->id  -->\n";
    	$expout .= "<table class=\"referentiel\">\n";

    	// add header
		
    	$expout .= "<h3>".get_string('certificat','referentiel')."</h3>\n";
		// 
		$expout .= "<tr>\n";		// 
		if ($record){
			// DEBUG
			// echo "<br />DEBUG LIGNE 1021<br />\n";
			// print_r($referentiel_instance);
			$id = trim( $record->id );
            $commentaire_certificat = trim($record->commentaire_certificat);
            $competences_certificat =  trim($record->competences_certificat) ;
            $decision_jury = trim($record->decision_jury);
            $date_decision = userdate(trim($record->date_decision));
            $userid = trim( $record->userid);
            $teacherid = trim( $record->teacherid);
            $ref_referentiel = trim( $record->ref_referentiel);
			$verrou = trim( $record->verrou );
			$valide = trim( $record->valide );
			$evaluation = trim( $record->evaluation );
			
			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			// USER
			if (isset($record->userid) && ($record->userid>0)){
				$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    	if ($record_etudiant){
					$expout .= $this->write_etudiant( $record_etudiant );
				}
			}
			
            $expout .= "<td><b>".get_string('commentaire_certificat','referentiel')."</b></td><td> $commentaire_certificat</td>\n";
            $expout .= "<td><b>".get_string('competences_certificat','referentiel')."</b></td><td> $competences_certificat</td>\n";
            $expout .= "<td><b>".get_string('decision_jury','referentiel')."</b></td><td> $decision_jury</td>\n";
            $expout .= "<td><b>".get_string('date_decision','referentiel')."</b></td><td> $date_decision</td>\n";
            $expout .= "<td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= "<td><b>".get_string('verrou','referentiel')."</b></td><td> $verrou</td>\n";
            $expout .= "<td><b>".get_string('valide','referentiel')."</b></td><td> $valide</td>\n";
            $expout .= "<td><b>".get_string('evaluation','referentiel')."</b></td><td> $evaluation</td>\n";
		}
	    $expout .= " </tr>\n";
		$expout .= "</table>\n\n";
		
        return $expout;
    }



	
	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
	    $id = $referentiel_instance->id;

    	// add comment and div tags
    	$expout .= "<!-- certification :  $referentiel_instance->id  name: $referentiel_instance->name -->\n";
    	// add header
    	$expout .= "<h2>$referentiel_instance->name</h2>\n";
		// 
    	$expout .= "<table class=\"referentiel\">\n";

		$expout .= "<tr>\n";
		// 
		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = trim($referentiel_instance->name);
            $description = trim($referentiel_instance->description_instance);
            $label_domaine = trim($referentiel_instance->label_domaine);
            $label_competence = trim($referentiel_instance->label_competence);
            $label_item = trim($referentiel_instance->label_item);
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;

			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= " <td><b>".get_string('name','referentiel')."</b></td><td> $name</td>\n";
			$expout .= " <td><b>".get_string('description','referentiel')."</b></td><td> $description</td>\n";   
            $expout .= " <td><b>".get_string('label_domaine','referentiel')."</b></td><td> $label_domaine</td>\n";
            $expout .= " <td><b>".get_string('label_competence','referentiel')."</b></td><td> $label_competence</td>\n";
            $expout .= " <td><b>".get_string('label_item','referentiel')."</b></td><td> $label_item</td>\n";			
            $expout .= " <td><b>".get_string('date_instance','referentiel')."</b></td><td> $date_instance</td>\n";
            $expout .= " <td><b>".get_string('course')."</b></td><td> $course</td>\n";
            $expout .= " <td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= " <td><b>".get_string('visible','referentiel')."</b></td><td> $visible</td>\n";
			
			// CERTIFICATS
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				$records_certificats = referentiel_get_certificats($referentiel_instance->ref_referentiel);
				// print_r($records_certificats);
				
		    	if ($records_certificats){
					foreach ($records_certificats as $record){
						$expout .= $this->write_certificat( $record );
					}
				}
			}
        }
	    $expout .= " </tr>\n";
		$expout .= "</table>\n";
        return $expout;
    }
}

// ETUDIANTS : export des etudiants
class eformat_html extends eformat_default {

    function provide_export() {
      return true;
    }

	function provide_import() {
        return false;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;

  		// get css bit
		$css_lines = file( "$CFG->dirroot/mod/referentiel/format/xhtml/xhtml.css" );
		$css = implode( ' ',$css_lines ); 
		$xp =  "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n";
		$xp .= "  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n";
		$xp .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
  		$xp .= "<head>\n";
  		$xp .= "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />\n";
  		$xp .= "<title>Moodle Referentiel :: Certificats XHTML Export</title>\n";
  		$xp .= $css;
  		$xp .= "</head>\n";
		$xp .= "<body>\n";
		$xp .= $content;
		$xp .= "</body>\n";
		$xp .= "</html>\n";

  		return $xp;
	}

	function export_file_extension() {
  		return "_h.html";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caracter 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }


	function write_etablissement( $record ) {
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\n\n<!-- etablissement: $record->id  -->\n";
		if ($record){
    		$expout .= "<table class=\"referentiel\">\n";
			// $expout .= "<h4>".get_string('etablissement','referentiel')."</h4>\n";
			$expout .= "<tr>\n";
			$id = trim( $record->id );
			$num_etablissement = trim( $record->num_etablissement);
			$nom_etablissement = trim( $record->nom_etablissement);
			$adresse_etablissement = trim( $record->adresse_etablissement);
			$logo = trim( $record->logo_etablissement);
			
			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
            $expout .= " <td><b>".get_string('num_etablissement','referentiel')."</b></td><td> $num_etablissement</td>\n";
            $expout .= " <td><b>".get_string('nom_etablissement','referentiel')."</b></td><td> $nom_etablissement</td>\n";			
            $expout .= " <td><b>".get_string('adresse_etablissement','referentiel')."</b></td><td> $adresse_etablissement</td>\n";
//            $expout .= " <td><b>".get_string('logo','referentiel')."</b></td><td> $logo</td>\n";			
			$expout .= " </tr>\n";
			$expout .= "</table>\n\n";
        }
        return $expout;
    }


	
	function write_etudiant( $record ) {
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\n\n<!-- etudiant: $record->id  -->\n";
		if ($record){
	    	// add header
			$expout .= "<table class=\"referentiel\">\n";
			
    		// $expout .= "<h4>".get_string('etudiant','referentiel')."</h4>\n";
			$expout .= "<tr>\n";		// 
			
			$id = trim( $record->id );
			$userid = trim( $record->userid );
            $ref_etablissement = trim( $record->ref_etablissement);
			$num_etudiant = trim( $record->num_etudiant);
			$ddn_etudiant = trim( $record->ddn_etudiant);
			$lieu_naissance = trim( $record->lieu_naissance);
			$departement_naissance = trim( $record->departement_naissance);
			$adresse_etudiant = trim( $record->adresse_etudiant);			
			
			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= " <td><b>".get_string('userid','referentiel')."</b></td><td> $userid</td>\n";	
			$expout .= " <td><b>".get_string('nom_prenom','referentiel')."</b></td><td> ".referentiel_get_user_info($record->userid)."</td>\n";
			$expout .= " <td><b>".get_string('num_etudiant','referentiel')."</b></td><td> $num_etudiant</td>\n";
            $expout .= " <td><b>".get_string('ddn_etudiant','referentiel')."</b></td><td> $ddn_etudiant</td>\n";
            $expout .= " <td><b>".get_string('lieu_naissance','referentiel')."</b></td><td> $lieu_naissance</td>\n";
            $expout .= " <td><b>".get_string('departement_naissance','referentiel')."</b></td><td> $departement_naissance</td>\n";			
            $expout .= " <td><b>".get_string('adresse_etudiant','referentiel')."</b></td><td> $adresse_etudiant</td>\n";
			$expout .= " <td><b>".get_string('ref_etablissement','referentiel')."</b></td><td> $ref_etablissement</td>\n";
			/*
			// Etablissement
			$record_etablissement=referentiel_get_etablissement($record->ref_etablissement);
	    	if ($record_etablissement){
				$expout .= $this->write_etablissement( $record_etablissement );
			}
			*/
		    $expout .= " </tr>\n";
			$expout .= "</table>\n\n";		//			
        }
        return $expout;
    }


	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_liste_etudiants( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
	    $id = $referentiel_instance->id;

    	// add comment and div tags
//    	$expout .= "<!-- etudiants :  $referentiel_instance->id  name: $referentiel_instance->name -->\n";
    	// add header
    	$expout .= "<h2>".get_string('etudiant','referentiel')."</h2>\n";
		// 
    	$expout .= "<table class=\"referentiel\">\n";

		$expout .= "<tr>\n";
		// 
		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = trim($referentiel_instance->name);
            $description = trim($referentiel_instance->description_instance);
            $label_domaine = trim($referentiel_instance->label_domaine);
            $label_competence = trim($referentiel_instance->label_competence);
            $label_item = trim($referentiel_instance->label_item);
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;
/*
			$expout .= " <td><b>".get_string('id','referentiel')."</b></td><td> $id</td>\n";
			$expout .= " <td><b>".get_string('name','referentiel')."</b></td><td> $name</td>\n";
			$expout .= " <td><b>".get_string('description','referentiel')."</b></td><td> $description</td>\n";   
            $expout .= " <td><b>".get_string('label_domaine','referentiel')."</b></td><td> $label_domaine</td>\n";
            $expout .= " <td><b>".get_string('label_competence','referentiel')."</b></td><td> $label_competence</td>\n";
            $expout .= " <td><b>".get_string('label_item','referentiel')."</b></td><td> $label_item</td>\n";			
            $expout .= " <td><b>".get_string('date_instance','referentiel')."</b></td><td> $date_instance</td>\n";
            $expout .= " <td><b>".get_string('course')."</b></td><td> $course</td>\n";
            $expout .= " <td><b>".get_string('ref_referentiel','referentiel')."</b></td><td> $ref_referentiel</td>\n";
            $expout .= " <td><b>".get_string('visible','referentiel')."</b></td><td> $visible</td>\n";
*/			
			// ETUDIANTS
			if (isset($referentiel_instance->course) && ($referentiel_instance->course>0)){
				// ETUDIANTS
				$records_all_students = referentiel_get_students_course($referentiel_instance->course);
				if ($records_all_students){
					foreach ($records_all_students as $record){
						// USER
						if (isset($record->userid) && ($record->userid>0)){
							$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    				if ($record_etudiant){
								$expout .= $this->write_etudiant( $record_etudiant );
							}
						}
					}
				}
			}
        }
	    $expout .= " </tr>\n";
		$expout .= "</table>\n";
        return $expout;
    }

	function write_liste_etablissements() {
    	global $CFG;
        // initial string;
        $expout = ""; 
		// ETABLISSEMENTS
		$records_all_etablissements = referentiel_get_etablissements();
		if ($records_all_etablissements){
			foreach ($records_all_etablissements as $record){
				if ($record){
					$expout.=$this->write_etablissement($record);
				}
			}
        }
        return $expout;
    }

}


?>
