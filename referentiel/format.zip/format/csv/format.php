<?php 
// Based on default.php, included by ../import.php

class rformat_csv extends rformat_default {

	var $sep = ";";
	
	var $table_caractere_input='latin1'; // par defaut import latin1
	var $table_caractere_output='latin1'; // par defaut export latin1
	
	// ----------------
	function recode_latin1_vers_utf8($s0){
	// retourne une chaine recode latin1
    	if (is_string($s0)){
	    // �����
    	// ëçöùñ
                    $s0=ereg_replace( "�", "é", $s0);
                    $s0=ereg_replace( "�", "è", $s0);
                    $s0=ereg_replace( "�", "ê", $s0);
                    $s0=ereg_replace( "�", "ë", $s0);
					$s0=ereg_replace( "�", "î", $s0);
                    $s0=ereg_replace( "�", "ï", $s0);
                    $s0=ereg_replace( "�", "à", $s0);
                    $s0=ereg_replace( "�", "ô", $s0);
                    $s0=ereg_replace( "�", "ö", $s0);
                    $s0=ereg_replace( "�", "ç", $s0);
                    $s0=ereg_replace( "�", "ù", $s0);
                    $s0=ereg_replace( "�", "ñ", $s0);
    	}
		return $s0;
	}


	// ----------------
	function recode_utf8_vers_latin1($s0){
	// retourne une chaine recode latin1
	
	    if (is_string($s0) && ereg("�", $s0)){
    		// �����
		    // ëçöùñ
                    $s0=ereg_replace( "é", "�", $s0 );
                    $s0=ereg_replace( "è", "�", $s0 );
                    $s0=ereg_replace( "ê", "�", $s0 );
                    $s0=ereg_replace( "ë", "�", $s0 );
					$s0=ereg_replace( "î", "�", $s0);
                    $s0=ereg_replace( "ï", "�", $s0);
                    $s0=ereg_replace( "à", "�", $s0);
                    $s0=ereg_replace( "ô", "�", $s0);
                    $s0=ereg_replace( "ö", "�", $s0);
                    $s0=ereg_replace( "ç", "�", $s0);
                    $s0=ereg_replace( "ù", "�", $s0);
                    $s0=ereg_replace( "ñ", "�", $s0);
    	}
		return $s0;
	}

	 /**
     * @param 
     * @return string recode latin1
	 * 
     */
    function input_codage_caractere($s){
		if (!isset($this->table_caractere_input) || ($this->table_caractere_input=="")){
			$this->table_caractere_input='latin1';
		}
		
		if ($this->table_caractere_input=='latin1'){
			$s=$this->recode_latin1_vers_utf8($s);
		}
		return $s;
	}
	
	 /**
     * @param 
     * @return string recode utf8
	 * 
     */
    function output_codage_caractere($s){
		if (!isset($this->table_caractere_output) || ($this->table_caractere_output=="")){
			$this->table_caractere_output='latin1';
		}
		
		if ($this->table_caractere_output=='latin1'){
			$s=$this->recode_utf8_vers_latin1($s);
		}
		return $s;
	}
	
    function provide_export() {
      return true;
    }

    function provide_import() {
      return true;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;
		global $USER;
		$xp =  "#Moodle Referentiel CSV Export;latin1;".referentiel_get_user_info($USER->id)."\n";
		$xp .= $content;
  		return $xp;
	}

	function export_file_extension() {
  		return ".csv";
	}

    /**
     * Turns item into an xml segment
     * @param item object
     * @return string xml segment
     */

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
		// 
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
            $code = $item->code_item;
            $description_item = $item->description_item;
            $ref_referentiel = $item->ref_referentiel;
            $ref_competence = $item->ref_competence;
			$type_item = $item->type_item;
			$poids_item = $item->poids_item;
			$num_item = $item->num_item;
			$empreinte_item = $item->empreinte_item;
            $expout .= stripslashes($this->output_codage_caractere($code)).";".stripslashes($this->output_codage_caractere($description_item)).";".$this->output_codage_caractere($type_item).";$poids_item;$num_item;$empreinte_item\n";
		}
        return $expout;
    }

	 /**
     * Turns competence into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_competence( $competence ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
		if ($competence){
            $code_competence = $competence->code_competence;
            $description_competence = $competence->description_competence;
            $ref_domaine = $competence->ref_domaine;
			$num_competence = $competence->num_competence;
			$nb_item_competences = $competence->nb_item_competences;
			$expout .= stripslashes($this->output_codage_caractere($code_competence)).";".stripslashes($this->output_codage_caractere($description_competence)).";$num_competence;$nb_item_competences\n";
							
			// ITEM
			$compteur_item=0;
			$records_items = referentiel_get_item_competences($competence->id);
			
			if ($records_items){
				// DEBUG
				// echo "<br/>DEBUG :: ITEMS <br />\n";
				// print_r($records_items);
				$expout .= "#code_item;description_item;type_item;poids_item;num_item;empreinte_item\n";				
				foreach ($records_items as $record_i){
					// DEBUG
					// echo "<br/>DEBUG :: ITEM <br />\n";
					// print_r($record_i);
					$expout .= $this->write_item( $record_i );
				}
			}
        }
        return $expout;
    }


	 /**
     * Turns domaine into an xml segment
     * @param domaine object
     * @return string xml segment
     */

    function write_domaine( $domaine ) {
    global $CFG;
        // initial string;
		$expout = "";
        // add comment		
		if ($domaine){
            $code_domaine = $domaine->code_domaine;
            $description_domaine = $domaine->description_domaine;
            $ref_referentiel = $domaine->ref_referentiel;
			$num_domaine = $domaine->num_domaine;
			$nb_competences = $domaine->nb_competences;			
			$expout .= stripslashes($this->output_codage_caractere($code_domaine)).";".stripslashes($this->output_codage_caractere($description_domaine)).";$num_domaine;$nb_competences\n";
			
			// LISTE DES COMPETENCES DE CE DOMAINE
			$compteur_competence=0;
			$records_competences = referentiel_get_competences($domaine->id);
			if ($records_competences){
				// DEBUG
				// echo "<br/>DEBUG :: COMPETENCES <br />\n";
				// print_r($records_competences);
				foreach ($records_competences as $record_c){
					$expout .= "#code_competence;description_competence;num_competence;nb_item_competences\n";
					$expout .= $this->write_competence( $record_c );
				}
			}
        }
        return $expout;
    }



	 /**
     * Turns referentiel into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_referentiel( $referentiel ) {
    	global $CFG;
        // initial string;
        $expout = "";
    	// add header
		$expout .= "#code_referentiel;nom_referentiel;description_referentiel;url_referentiel;date_creation;nb_domaines;seuil_certificat;liste_codes_competences;liste_empreintes;logo_referentiel\n";

		if ($referentiel){
		    $id = $referentiel->id;
            $name = $referentiel->name;
            $code_referentiel = $referentiel->code_referentiel;
            $description_referentiel = $referentiel->description_referentiel;
            $url_referentiel = $referentiel->url_referentiel;
			$seuil_certificat = $referentiel->seuil_certificat;
			$timemodified = $referentiel->timemodified;
			$nb_domaines = $referentiel->nb_domaines;
			$liste_codes_competence = $referentiel->liste_codes_competence;
			$local = $referentiel->local;
			$liste_empreintes_competence = $referentiel->liste_empreintes_competence;
			$logo_referentiel = $referentiel->logo_referentiel;

			// PAS DE LOGO ICI 
			// $expout .= stripslashes($this->output_codage_caractere($code_referentiel)).";".stripslashes($this->output_codage_caractere($name)).";".$this->output_codage_caractere($description_referentiel).";$url_referentiel;$timemodified;$nb_domaines;$seuil_certificat;".stripslashes($this->output_codage_caractere($liste_codes_competence)).";".stripslashes($this->output_codage_caractere($liste_empreintes_competence)).";".$logo_referentiel."\n";
			$expout .= stripslashes($this->output_codage_caractere($code_referentiel)).";".stripslashes($this->output_codage_caractere($name)).";".$this->output_codage_caractere($description_referentiel).";$url_referentiel;".referentiel_timestamp_date_special($timemodified).";$nb_domaines;$seuil_certificat;".stripslashes($this->output_codage_caractere($liste_codes_competence)).";".stripslashes($this->output_codage_caractere($liste_empreintes_competence))."\n";			
			// DOMAINES
			if (isset($referentiel->id) && ($referentiel->id>0)){
				// LISTE DES DOMAINES
				$compteur_domaine=0;
				$records_domaine = referentiel_get_domaines($referentiel->id);
		    	if ($records_domaine){
    				// afficher
					// DEBUG
					// echo "<br/>DEBUG ::<br />\n";
					// print_r($records_domaine);
					foreach ($records_domaine as $record_d){
						// DEBUG
						// echo "<br/>DEBUG ::<br />\n";
						// print_r($records_domaine);
						$expout .= "#code_domaine;description_domaine;ref_referentiel;num_domaine;nb_competences\n";						
						$expout .= $this->write_domaine( $record_d );
					}
				}
			} 
        }
        return $expout;
    }
	
	/***************************************************************************
		
	// IMPORT FUNCTIONS START HERE
	
	***************************************************************************/
     /**
	 * @param array referentiel array from xml tree
     * @return object import_referentiel object
	 * modifie la base de donnees 
     */
    function importation_referentiel_possible(){
	// selon les parametres soit cree une nouvelle instance 
	// soit modifie une instance courante de referentiel
	global $CFG;
		
		if (!isset($this->action) || (isset($this->action) && ($this->action!="selectreferentiel") && ($this->action!="importreferentiel"))){
			if (!(isset($this->course->id) && ($this->course->id>0)) 
				|| 
				!(isset($this->rreferentiel->id) && ($this->rreferentiel->id>0))
				|| 
				!(isset($this->coursemodule->id) && ($this->coursemodule->id>0))
				){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="selectreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="importreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		return true;
	}
	
	
     /**
	 * @param array referentiel array from xml tree
     * @return object import_referentiel object
	 * modifie la base de donnees 
     */
    function import_referentiel( $lines ) {
	// recupere le tableau de lignes 
	// selon les parametres soit cree une nouvelle instance 
	// soit modifie une instance courante de referentiel
	global $SESSION;
	global $USER;
	global $CFG;
	
	if (!$this->importation_referentiel_possible()){
		exit;
	}
	
	// initialiser les variables
	// id du nouveau referentiel si celui ci doit �tre cree
	$new_referentiel_id=0;
	$auteur="";	
	$l_id_referentiel = "id_referentiel";
   	$l_code_referentiel = "code_referentiel";
    $l_description_referentiel = "description_referentiel";
	$l_date_creation = "date_creation";
	$l_nb_domaine = "nb_domaine";
	$l_seuil_certification = "seuil_certificat";
	$l_local = "local";
	$l_name = "name";
	$l_url_referentiel = "url_referentiel";
	$l_liste_competences= "liste_competences";
	$l_liste_empreintes= "liste_empreintes";
	$l_logo= "logo_referentiel";	
	$ok_referentiel_charge=false;
	$ok_domaine_charge=false;
	$ok_competence_charge=false;
	$ok_item_charge=false;
	
	$risque_ecrasement=false;
		
    // get some error strings
    $error_noname = get_string( 'xmlimportnoname', 'referentiel' );
    $error_nocode = get_string( 'xmlimportnocode', 'referentiel' );
	$error_override = get_string( 'overriderisk', 'referentiel' );
	
	// DEBUT	
	// Decodage 
	$line = 0;
	// TRAITER LA LIGNE D'ENTETE
	$nbl=count($lines);
	if ($nbl>0){ // premiere ligne entete fichier csv
		// echo "<br>$line : ".$lines[$line]."\n";
		
		// "#Moodle Referentiel CSV Export;latin1;Pr�nom NOM\n";
		
        $fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
	  	$line++;
		if (substr($lines[$line],0,1)=='#'){
			// labels			
	        /// If a line is incorrectly formatted 
            if (count($fields) < 3 ) {
	           	if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
					$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted - ignoring\n");
				}
           	}
			if (isset($fields[1]) && ($fields[1]!="")){
		        $this->table_caractere_input=trim($fields[1]);
			}
			$auteur=trim($fields[2]);
		}
	}
	else{
		$this->error("ERROR : CSV File incorrect\n");
	}
	
	// echo "<br />DEBUG :: 991 : $this->table_caractere_input\n";
	
	
	if ($nbl>1){ // deuxieme ligne : entete referentiel
		// echo "<br>$line : ".$lines[$line]."\n";
		// #code_referentiel;name;description_referentiel;url_referentiel;date_creation;
		// nb_domaines;seuil_certification;liste_competences
        $fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
        /// If a line is incorrectly formatted 
        if (count($fields) < 3 ) {
           	if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
				$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted");
    		}
		}
		if (substr($lines[$line],0,1)=='#'){
			// labels
    	    $l_code_referentiel = trim($fields[0]);
			$l_name = trim($fields[1]);
	        $l_description_referentiel = trim($fields[2]);
			if (isset($fields[3]))
				$l_url_referentiel = trim($fields[3]);
			else
				$l_url_referentiel = "";
			if (isset($fields[4]))
			    $l_date_creation = trim($fields[4]);
			else
				$l_date_creation = "";
			if (isset($fields[5])) 
				$l_nb_domaines = trim($fields[5]);
			else
				$l_nb_domaines = "";
			if (isset($fields[6])) 
				$l_seuil_certificat = trim($fields[6]);
			else
				$l_seuil_certificat = "";
			if (isset($fields[7]))
				$l_liste_competences = trim($fields[7]);
			else
				$l_liste_competences = "";
			if (isset($fields[8]))
				$l_liste_empreintes = trim($fields[8]);
			else
				$l_liste_empreintes = "";
			if (isset($fields[9]))
				$l_logo = trim($fields[9]);
			else
				$l_logo = "";
		}
		else{
			// data  : referentiel
    		$code_referentiel = $this->input_codage_caractere(trim($fields[0]));
	    	$name = $this->input_codage_caractere(trim($fields[1]));
			$description_referentiel = $this->input_codage_caractere(trim($fields[2]));
			if (isset($fields[3]))
				$url_referentiel = trim($fields[3]);
			else
				$url_referentiel = "";
			if (isset($fields[4]))
				$date_creation = trim($fields[4]);
			else
				$date_creation = "";
			if (isset($fields[5]))
				$nb_domaines = trim($fields[5]);
			else
				$nb_domaines = "";
			if (isset($fields[6]))
				$seuil_certificat = trim($fields[6]);
			else
				$seuil_certificat = "";
			if (isset($fields[7]))
				$liste_competences = $this->input_codage_caractere(trim($fields[7]));
			else
				$liste_competences = "";
			if (isset($fields[8]))
				$liste_empreintes = $this->input_codage_caractere(trim($fields[8]));
			else
				$liste_empreintes = "";
			if (isset($fields[9]))
				$logo_referentiel = trim($fields[9]);
			else
				$logo_referentiel = "";
			$ok_referentiel_charge=true;
		}
		$line++;
	}
	
	// maintenant les donn�es indispensables
	while (($line<$nbl) && ($ok_referentiel_charge==false)){ // data : referentiel
		// echo "<br>$line : ".$lines[$line]."\n";
		// #referentiel_id;code_referentiel;description_referentiel;date_creation;
		// nb_domaines;seuil_certificat;local;name;url_referentiel;liste_competences
        $fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
        /// If a line is incorrectly formatted 
        if (count($fields) < 3 ) {
          	if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
				$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted");
    		}
			continue;
		}
		// DEBUG
		// print_r($fields);
		// data  : referentiel
    	$code_referentiel = $this->input_codage_caractere(trim($fields[0]));
	    $name = $this->input_codage_caractere(trim($fields[1]));
		$description_referentiel = $this->input_codage_caractere(trim($fields[2]));
		if (isset($fields[3]))
			$url_referentiel = trim($fields[3]);
		else
			$url_referentiel = "";
		if (isset($fields[4]))
			$date_creation = trim($fields[4]);
		else
			$date_creation = "";
		if (isset($fields[5]))
			$nb_domaines = trim($fields[5]);
		else
			$nb_domaines = "";
		if (isset($fields[6]))
			$seuil_certificat = trim($fields[6]);
		else
			$seuil_certificat = "";
		if (isset($fields[7]))
			$liste_competences= $this->input_codage_caractere(trim($fields[7]));
		else
			$liste_competences= "";
		if (isset($fields[8]))
			$liste_empreintes = $this->input_codage_caractere(trim($fields[8]));
		else
			$liste_empreintes = "";
		if (isset($fields[9]))
			$logo_referentiel = trim($fields[9]);
		else
			$logo_referentiel = "";
			
		$ok_referentiel_charge=true;
	  	$line++;
	}
	
	if (!$ok_referentiel_charge){
		$this->error( get_string( 'incompletedata', 'referentiel' ) );
	}
	// this routine initialises the import object
    $re = $this->defaultreferentiel();
	
	$re->name=str_replace("'", " ",$name);
	// $re->name=addslashes($name);
	$re->code_referentiel=$code_referentiel;
	$re->description_referentiel=str_replace("'", "`",$description_referentiel);
	// $re->description_referentiel=addslashes($description_referentiel);
	$re->url_referentiel=$url_referentiel;
	$re->seuil_certificat=$seuil_certificat;
	$re->timemodified = $date_creation;
	$re->nb_domaines=$nb_domaines;
	$re->liste_codes_competence=$liste_competences;
	$re->liste_empreintes_competence=$liste_empreintes;
	$re->logo_referentiel=$logo_referentiel;
	
	/*
	// GROS BUG
	if ($id_referentiel!=""){
		$re->id=$id_referentiel;
	}
	*/
	$re->id=0;
	
	// DEBUG
	// print_r($re);
	
	// RISQUE ECRASEMENT ?
	$risque_ecrasement = false; // 
	if (($this->rreferentiel) && ($this->rreferentiel->id>0)){ // charger le referentiel associ� � l'instance
		$referentiel_referentiel = referentiel_get_referentiel_referentiel($this->rreferentiel->id);
		if ($referentiel_referentiel){
			$risque_ecrasement = (($referentiel_referentiel->name==$re->name) && ($referentiel_referentiel->code_referentiel==$re->code_referentiel));
		}
	}
	
	// SI OUI arr�ter
	if ($risque_ecrasement==true){
		if ($this->override!=1){
			$this->error($error_override);
		}
		else {
			// le referentiel courant est remplace
			$new_referentiel_id=$referentiel_referentiel->id;
			$re->id=$new_referentiel_id;
		}
	}
	
	$re->export_process = false;
	$re->import_process = true;
	
	// le referentiel est toujours place dans le cours local d'appel 
	$re->course = $this->course->id;
	
	$risque_ecrasement=false;
	if (!isset($this->action) || ($this->action!="importreferentiel")){
		// importer dans le cours courant en remplacement du referentiel courant
		// Verifier si ecrasement referentiel local
		if (isset($re->name) && ($re->name!="")
			&& 
			isset($re->code_referentiel) && ($re->code_referentiel!="")
			&& 
			isset($re->id) && ($re->id>0)
			&& 
			isset($re->course) && ($re->course>0))
		{
			// sauvegarder ?
			if ($this->course->id==$re->course){
				if 	(
						(isset($this->rreferentiel->id) && ($this->rreferentiel->id==$re->id))
						|| 
						(	
							(isset($this->rreferentiel->name) && ($this->rreferentiel->name==$re->name)) 
							&& 
							(isset($this->rreferentiel->code_referentiel) && ($this->rreferentiel->code_referentiel==$re->code_referentiel))
						)
					)
				{
					$risque_ecrasement=true;
				}
			}
		}
	}
	
	// DEBUG
	/*
	if ($risque_ecrasement)
		echo "<br />DEBUG : 607 : Risque d'ecrasement N:$this->newinstance O:$this->override\n";
	else 
		echo "<br />DEBUG : 607 : Pas de risque d'ecrasement N:$this->newinstance O:$this->override\n";
	*/
	
	if (($risque_ecrasement==false) || ($this->newinstance==1)) {
		// Enregistrer dans la base comme un nouveau referentiel du cours courant
		// DEBUG
		// echo "<br />DEBUG csv/format.php ligne 628<br />\n";
		// print_object($re);
		
		$new_referentiel_id=referentiel_add_referentiel($re); // retourne un id de la table refrentiel_referentiel
		$this->setReferentielId($new_referentiel_id);
	}
	else if (($risque_ecrasement==true) && ($this->override==1)) {
		// Enregistrer dans la base en rempla�ant la version courante (update)
		// NE FAUDRAIT IL PAS SUPPRIMER LE REFERENTIEL AVANT DE LA RECHARGER ?
		$re->instance=$this->rreferentiel->id;
		$re->referentiel_id=$this->rreferentiel->id;
		// DEBUG
		// echo "<br />DEBUG csv/format.php ligne 638<br />MISE A JOUR  : ".$r->rreferentiel_id."\n";

		$ok=referentiel_update_referentiel($re); // retourne un id de la table referentiel_referentiel
		$new_referentiel_id=$this->rreferentiel->id;
	}
	else {
		// ni nouvelle instance ni recouvrement
		$this->error("ERREUR 2 ".$error_override );
		return false;
	}
	
	if (isset($new_referentiel_id) && ($new_referentiel_id>0)){
		// IMPORTER LE RESTE DU REFERENTIEL
		$dindex=0;
		$cindex=0;
		$iindex=0;
		
        $re->domaines = array();
		$new_domaine_id=0;
		$new_competence_id=0;
				
		$numero_domaine=0; // compteur pour suppleer le numero si non importe
		$numero_competence=0;
		$numero_item=0;
		$num_domaine=0;
		$num_competence=0;
		$num_item=0;
		
		$is="";
		$is_domaine=false;
		$is_competence=false;
		$is_item=false;

		$mode="add";
		
		while ($line<$nbl) {
			// echo "<br />DEBUG 652 :: <br />".$lines[$line]."\n";
           	$fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
	        if (count($fields) < 2 ) {
    	      	if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
					$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted");
    			}
				continue;
			}
			
			// print_r($fields);
			// Label ou data ?
			// echo "<br />".substr($fields[0],0,1)."\n";
			
			if (substr($fields[0],0,1)=='#'){
				// labels
				// on s'en sert pour construire l'arbre
				$is=trim($fields[0]);
				$is_domaine=false;
				$is_competence=false;
				$is_item=false;
				
				switch($is){
					case '#code_domaine' :
						// #code_domaine;description_domaine;num_domaine;nb_competences
						$is_domaine=true;
					break;
					case '#code_competence' :
						// #code_competence;description_competence;num_competence;nb_item_competences
						$is_competence=true;
					break;
					case '#code_item' :
						// #code_item;description_item;type_item;poids_item;num_item
						$is_item=true;
					break;
					default :
						$this->error("ERROR : CSV File incorrect line number:".$line."\n");
					break;
				}
			}
			else if (isset($is) && ($is!="")){
				// data
				switch($is){
					case '#code_domaine' :
						// $code_domaine;$description_domaine;$num_domaine;$nb_competences
						// Domaines
						// data
						$code_domaine = addslashes($this->input_codage_caractere(trim($fields[0])));
						$description_domaine = addslashes($this->input_codage_caractere(trim($fields[1])));
						$num_domaine = trim($fields[2]);
						$nb_competences = trim($fields[3]);
						
						if ($code_domaine!=""){
							// Creer un domaine
							$numero_domaine++; 
							$new_domaine = array();
							$new_domaine = $this->defaultdomaine();
							
							$new_domaine->code_domaine=$code_domaine;
							if ($description_domaine!="")
								$new_domaine->description_domaine = $description_domaine;
							
							if ($num_domaine!="")
								$new_domaine->num_domaine=$num_domaine;
							else
								$new_domaine->num_domaine=$numero_domaine;
							if ($nb_competences!="")
								$new_domaine->nb_competences=$nb_competences;
							else
								$new_domaine->nb_competences=0;
							
							$new_domaine->ref_referentiel=$new_referentiel_id;
							
							// sauvegarder dans la base
							// remplacer l'id du referentiel importe par l'id du referentiel cree
							// trafiquer les donnees pour appeler la fonction ad hoc
							$new_domaine->ref_referentiel=$new_referentiel_id;
							$new_domaine->instance=$new_referentiel_id; // pour que ca marche
							$new_domaine->new_code_domaine=$new_domaine->code_domaine;
							$new_domaine->new_description_domaine=$new_domaine->description_domaine;
							$new_domaine->new_num_domaine=$new_domaine->num_domaine;
							$new_domaine->new_nb_competences=$new_domaine->num_domaine;
							$new_domaine_id=referentiel_add_domaine($new_domaine);
							
							if (isset($new_domaine_id) && ($new_domaine_id>0)){
								$new_domaine->id=$new_domaine_id;
							}
							else{
								$new_domaine->id=0;
							}
							
							// enregistrer
							$dindex++;
							$re->domaines[$dindex]=$new_domaine;
							$cindex=0;
							$re->domaines[$dindex]->competences=array();
							$numero_competence=0;
							$ok_domaine_charge=true;
						}
						else{
							$ok_domaine_charge=false;
						}
					break;
					case '#code_competence' :
						// $competence_id;$code_competence;$description_competence;$ref_domaine;
						// $num_competence;$nb_item_competences
						$code_competence = addslashes($this->input_codage_caractere(trim($fields[0])));
						$description_competence = addslashes($this->input_codage_caractere(trim($fields[1])));
						$num_competence = trim($fields[2]);
						$nb_item_competences = trim($fields[3]);
						
						if (($code_competence!="") && ($ok_domaine_charge) && ($new_domaine_id>0)){
							// Creer une competence
							$new_competence_id=0;
							$numero_competence++; 
							$new_competence = array();
							$new_competence = $this->defaultcompetence();
							
							$new_competence->id=0;	
							$new_competence->code_competence=$code_competence;
							if ($description_competence!="")
								$new_competence->description_competence = $description_competence;
							if ($num_competence!="")
								$new_competence->num_competence=$num_competence;
							else
								$new_competence->num_competence=$numero_competence;
							if ($nb_item_competences!="")
								$new_competence->nb_item_competences=$nb_item_competences;
							else
								$new_competence->nb_item_competences=0;
								
							if (isset($new_domaine_id) && ($new_domaine_id>0)){
								$new_competence->ref_domaine=$new_domaine_id;
							}
							else{
								$new_competence->ref_domaine=0;
							}
							
							// sauvegarder dans la base
							// remplacer l'id du referentiel importe par l'id du referentiel cree
							$new_competence->ref_domaine=$new_domaine_id;
							// trafiquer les donnees pour appeler la fonction ad hoc
							$new_competence->instance=$new_referentiel_id; // pour que ca marche
							$new_competence->new_code_competence=$new_competence->code_competence;
							$new_competence->new_description_competence=$new_competence->description_competence;
							$new_competence->new_ref_domaine=$new_domaine_id;
							$new_competence->new_num_competence=$new_competence->num_competence;
							$new_competence->new_nb_item_competences=$new_competence->nb_item_competences;
							// creation
							$new_competence_id=referentiel_add_competence($new_competence);
							$new_competence->id=$new_competence_id;
							
							// enregistrer
							$cindex++;
							$re->domaines[$dindex]->competences[$cindex]=$new_competence;
							$iindex=0; // nouveaux items � suivre
							$re->domaines[$dindex]->competences[$cindex]->items=array();
							
							$numero_item=0;
							$ok_competence_charge=true;
						}
						else{
							$ok_competence_charge=false;
						}
					break;
					case '#code_item' :
						// $code_item;$description_item;$type_item;$poids_item;$num_item;$empreinte_item
						$code_item = $this->input_codage_caractere(addslashes(trim($fields[0])));
						$description_item = $this->input_codage_caractere(addslashes(trim($fields[1])));
						$type_item = $this->input_codage_caractere(addslashes(trim($fields[2])));
						$poids_item = trim($fields[3]);
						$num_item = trim($fields[4]);
						if (isset($fields[5]) && (trim($fields[5])!="")){
							$empreinte_item = trim($fields[5]);
						}
						else{
							$empreinte_item = "1";
						}
						if (($code_item!="") && ($ok_competence_charge) && ($new_competence_id>0)){
							// Creer un domaine
							$numero_item++; 
							$new_item = array();
							$new_item = $this->defaultitem();
							$new_item->code_item=$code_item;
							if ($description_item!="")
								$new_item->description_item = $description_item;
							$new_item->ref_referentiel=$new_referentiel_id;
							$new_item->ref_competence=$new_competence_id;
							$new_item->type_item=$type_item;
							$new_item->poids_item=$poids_item;
							if ($num_item!="")
								$new_item->num_item=$num_item;
							else
								$new_item->num_item=$numero_item;
							$new_item->empreinte_item=$empreinte_item;
														
							// sauvegarder dans la base
							// remplacer l'id du referentiel importe par l'id du referentiel cree
							$new_item->ref_referentiel=$new_referentiel_id;
							$new_item->ref_competence=$new_competence_id;
							// trafiquer les donnees pour pouvoir appeler la fonction ad hoc
							$new_item->instance=$new_item->ref_referentiel;
							$new_item->new_ref_competence=$new_item->ref_competence;
							$new_item->new_code_item=$new_item->code_item;
							$new_item->new_description_item=$new_item->description_item;
							$new_item->new_num_item=$new_item->num_item;
							$new_item->new_type_item=$new_item->type_item;
							$new_item->new_poids_item=$new_item->poids_item;
							$new_item->new_empreinte_item=$new_item->empreinte_item;
							// creer
							$new_item_id=referentiel_add_item($new_item);
							$new_item->id=$new_item_id;
							
							$iindex++;				
							$re->domaines[$dindex]->competences[$cindex]->items[$iindex]=$new_item; 
							$ok_item_charge=true;
						}
						else{
							$ok_item_charge=false;
						}
					break;
					default :
						$this->error("ERROR : CSV File incorrect line number:".$line."\n");
					break;
				}
			}
			// that's all folks
			$line++;
        } // end of while loop
		if ($mode=="add"){
			// rien de special ici ?
		}
	    return $re;
	}
	return false;
}


    /**
     * parse the array of lines into an array of questions
     * this *could* burn memory - but it won't happen that much
     * so fingers crossed!
     * @param array lines array of lines from the input file
     * @return array (of objects) question objects
     */
    function read_import_referentiel($lines) {
        // we just need it as one array
		$re=$this->import_referentiel($lines);
        return $re;
    }
}


/** ******************************************

EXPORT ACTIVITES

*/

// ACTIVITES : export des activites
class aformat_csv extends aformat_default {
// NON SUPPORTE POUR LE FORMAT CSV
		var $sep = ";";
	
	var $table_caractere_input='latin1'; // par defaut import latin1
	var $table_caractere_output='latin1'; // par defaut export latin1
	
	// ----------------
	function recode_latin1_vers_utf8($s0){
	// retourne une chaine recode latin1
    	if (is_string($s0)){
	    // �����
    	// ëçöùñ
                    $s0=ereg_replace( "�", "é", $s0);
                    $s0=ereg_replace( "�", "è", $s0);
                    $s0=ereg_replace( "�", "ê", $s0);
                    $s0=ereg_replace( "�", "ë", $s0);
					$s0=ereg_replace( "�", "î", $s0);
                    $s0=ereg_replace( "�", "ï", $s0);
                    $s0=ereg_replace( "�", "à", $s0);
                    $s0=ereg_replace( "�", "ô", $s0);
                    $s0=ereg_replace( "�", "ö", $s0);
                    $s0=ereg_replace( "�", "ç", $s0);
                    $s0=ereg_replace( "�", "ù", $s0);
                    $s0=ereg_replace( "�", "ñ", $s0);
    	}
		return $s0;
	}


	// ----------------
	function recode_utf8_vers_latin1($s0){
	// retourne une chaine recode latin1
	
	    if (is_string($s0) && ereg("�", $s0)){
    		// �����
		    // ëçöùñ
                    $s0=ereg_replace( "é", "�", $s0 );
                    $s0=ereg_replace( "è", "�", $s0 );
                    $s0=ereg_replace( "ê", "�", $s0 );
                    $s0=ereg_replace( "ë", "�", $s0 );
					$s0=ereg_replace( "î", "�", $s0);
                    $s0=ereg_replace( "ï", "�", $s0);
                    $s0=ereg_replace( "à", "�", $s0);
                    $s0=ereg_replace( "ô", "�", $s0);
                    $s0=ereg_replace( "ö", "�", $s0);
                    $s0=ereg_replace( "ç", "�", $s0);
                    $s0=ereg_replace( "ù", "�", $s0);
                    $s0=ereg_replace( "ñ", "�", $s0);
    	}
		return $s0;
	}

	 /**
     * @param 
     * @return string recode latin1
	 * 
     */
    function input_codage_caractere($s){
		if (!isset($this->table_caractere_input) || ($this->table_caractere_input=="")){
			$this->table_caractere_input='latin1';
		}
		
		if ($this->table_caractere_input=='latin1'){
			$s=$this->recode_latin1_vers_utf8($s);
		}
		return $s;
	}
	
	 /**
     * @param 
     * @return string recode utf8
	 * 
     */
    function output_codage_caractere($s){
		if (!isset($this->table_caractere_output) || ($this->table_caractere_output=="")){
			$this->table_caractere_output='latin1';
		}
		
		if ($this->table_caractere_output=='latin1'){
			$s=$this->recode_utf8_vers_latin1($s);
		}
		return $s;
	}



    function provide_export() {
      return true;
    }

	function provide_import() {
        return false;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers

  		global $CFG;
		$xp =  "Moodle Referentiel CSV Export\n";
		$xp .= $content;
  		return $xp;
	}

	function export_file_extension() {
  		return ".csv";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caractere 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }

	 /**
     * Turns document into an xml segment
     * @param document object
     * @return string xml segment
     */

    function write_document( $document ) {
    global $CFG;
       // initial string;
        $expout = "";
		if ($document){
			$id_document = $document->id ;		
            $type_document = trim($document->type_document);
            $description_document = trim($document->description_document);
			$url_document = $document->url_document;
            $ref_activite = $document->ref_activite;
			$expout .= "#id_document;type_document;description_document;url_document;ref_activite\n";
            $expout .= "$id_document;".stripslashes($this->output_codage_caractere($type_document)).";".stripslashes($this->output_codage_caractere($description_document)).";$url_document;$ref_activite\n";   
        }
        return $expout;
    }

    /**
     * Turns activite into an xml segment
     * @param activite object
     * @return string xml segment
     */

    function write_activite( $activite ) {
    global $CFG;
       // initial string;
        $expout = "";
        // add comment
		if ($activite){
			// DEBUG
			// echo "<br />\n";
			// print_r($activite);
			$id_activite = $activite->id;
            $type_activite = trim($activite->type_activite);
            $description_activite = trim($activite->description_activite);
            $competences_activite = trim($activite->competences_activite);
            $commentaire_activite = trim($activite->commentaire_activite);
            $ref_instance = $activite->ref_instance;
            $ref_referentiel = $activite->ref_referentiel;
            $ref_course = $activite->ref_course;
			$userid = trim($activite->userid);
			$teacherid = $activite->teacherid;
			$date_creation = $activite->date_creation;
			$date_modif = $activite->date_modif;
			$approved = $activite->approved;
			
			$expout .= "#id_activite;type_activite;description_activite;competences_activite;commentaire_activite;ref_instance;ref_referentiel;ref_course;userid;teacherid;date_creation;date_modif;approved\n";
			$expout .= "$id_activite;".stripslashes($this->output_codage_caractere($type_activite)).";".stripslashes($this->output_codage_caractere($description_activite)).";".stripslashes($this->output_codage_caractere($competences_activite)).";".stripslashes($this->output_codage_caractere($commentaire_activite)).";$ref_instance;$ref_referentiel;$ref_course;$userid;$teacherid;".referentiel_timestamp_date_special($date_creation).";".referentiel_timestamp_date_special($date_modif).";$approved\n";
			
			// DOCUMENTS
			$records_documents = referentiel_get_documents($activite->id);
			
			if ($records_documents){
				foreach ($records_documents as $record_d){
					$expout .= $this->write_document( $record_d );
				}
			}
		}	
        return $expout;
    }

	
	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
		// 
		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = trim($referentiel_instance->name);
            $description_instance = trim($referentiel_instance->description_instance);
            $label_domaine = trim($referentiel_instance->label_domaine);
            $label_competence = trim($referentiel_instance->label_competence);
            $label_item = trim($referentiel_instance->label_item);
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;
			
			// $expout .= "#Instance de referentiel : $referentiel_instance->name\n";
			$expout .= "#id_instance;name;description_instance;label_domaine;label_competence;label_item;date_instance;course;ref_referentiel;visible\n";
			$expout .= "$id;".stripslashes($this->output_codage_caractere($name)).";".stripslashes($this->output_codage_caractere($description_instance)).";".stripslashes($this->output_codage_caractere($label_domaine)).";".stripslashes($this->output_codage_caractere($label_competence)).";".stripslashes($this->output_codage_caractere($label_item)).";".referentiel_timestamp_date_special($date_instance).";$course;$ref_referentiel;$visible\n";
			
			// ACTIVITES
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				$records_activites = referentiel_get_activites($referentiel_instance->ref_referentiel);
		    	if ($records_activites){
					foreach ($records_activites as $record_a){
						// DEBUG
						// print_r($record_a);
						// echo "<br />\n";
						$expout .= $this->write_activite( $record_a );
					}
				}
			}
		}
        return $expout;
    }
}

// ##########################################################################################################
// *************************************
// CERTIFICATS : export des certificats
// *************************************
class cformat_csv extends cformat_default {
		var $sep = ";";
	
	var $table_caractere_input='latin1'; // par defaut import latin1
	var $table_caractere_output='latin1'; // par defaut export latin1
	
	// ----------------
	function recode_latin1_vers_utf8($s0){
	// retourne une chaine recode latin1
    	if (is_string($s0)){
	    // �����
    	// ëçöùñ
                    $s0=ereg_replace( "�", "é", $s0);
                    $s0=ereg_replace( "�", "è", $s0);
                    $s0=ereg_replace( "�", "ê", $s0);
                    $s0=ereg_replace( "�", "ë", $s0);
					$s0=ereg_replace( "�", "î", $s0);
                    $s0=ereg_replace( "�", "ï", $s0);
                    $s0=ereg_replace( "�", "à", $s0);
                    $s0=ereg_replace( "�", "ô", $s0);
                    $s0=ereg_replace( "�", "ö", $s0);
                    $s0=ereg_replace( "�", "ç", $s0);
                    $s0=ereg_replace( "�", "ù", $s0);
                    $s0=ereg_replace( "�", "ñ", $s0);
    	}
		return $s0;
	}


	// ----------------
	function recode_utf8_vers_latin1($s0){
	// retourne une chaine recode latin1
	
	    if (is_string($s0) && ereg("�", $s0)){
    		// �����
		    // ëçöùñ
                    $s0=ereg_replace( "é", "�", $s0 );
                    $s0=ereg_replace( "è", "�", $s0 );
                    $s0=ereg_replace( "ê", "�", $s0 );
                    $s0=ereg_replace( "ë", "�", $s0 );
					$s0=ereg_replace( "î", "�", $s0);
                    $s0=ereg_replace( "ï", "�", $s0);
                    $s0=ereg_replace( "à", "�", $s0);
                    $s0=ereg_replace( "ô", "�", $s0);
                    $s0=ereg_replace( "ö", "�", $s0);
                    $s0=ereg_replace( "ç", "�", $s0);
                    $s0=ereg_replace( "ù", "�", $s0);
                    $s0=ereg_replace( "ñ", "�", $s0);
    	}
		return $s0;
	}

	 /**
     * @param 
     * @return string recode latin1
	 * 
     */
    function input_codage_caractere($s){
		if (!isset($this->table_caractere_input) || ($this->table_caractere_input=="")){
			$this->table_caractere_input='latin1';
		}
		
		if ($this->table_caractere_input=='latin1'){
			$s=$this->recode_latin1_vers_utf8($s);
		}
		return $s;
	}
	
	 /**
     * @param 
     * @return string recode utf8
	 * 
     */
    function output_codage_caractere($s){
		if (!isset($this->table_caractere_output) || ($this->table_caractere_output=="")){
			$this->table_caractere_output='latin1';
		}
		
		if ($this->table_caractere_output=='latin1'){
			$s=$this->recode_utf8_vers_latin1($s);
		}
		return $s;
	}

    function provide_export() {
      return true;
    }

	function provide_import() {
        return false;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers
  		global $CFG;
		$xp =  "#Moodle Certification CSV Export;latin1;\n";
		$xp .= $content;
  		return $xp;
	}

	function export_file_extension() {
  		return ".csv";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caracter 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\nitem: $item->id\n";
		// $expout .= "id;code_item;description_item;ref_referentiel;ref_competence;type_item;poids_item;num_item\n";
		// 
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
			$id_item = $item->id;
            $code = $item->code_item;
            $description_item = $item->description_item;
            $ref_referentiel = $item->ref_referentiel;
            $ref_competence = $item->ref_competence;
			$type_item = $item->type_item;
			$poids_item = $item->poids_item;
			$num_item = $item->num_item;
			$empreinte_item = $item->empreinte_item;
            $expout .= "$id_item;".stripslashes($this->output_codage_caractere($code)).";".stripslashes($this->output_codage_caractere($description_item)).";".$this->output_codage_caractere($type_item).";$poids_item;$num_item;$empreinte_item\n";
		}
        return $expout;
    }

	 /**
     * Turns competence into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_competence( $competence ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        // $expout .= "\ncompetence: $competence->id\n";
		if ($competence){
			$id_competence = $competence->id;
            $code = $competence->code_competence;
            $description_competence = $competence->description_competence;
            $ref_domaine = $competence->ref_domaine;
			$num_competence = $competence->num_competence;
			$nb_item_competences = $competence->nb_item_competences;
			$expout .= "$id_competence;".stripslashes($this->output_codage_caractere($code)).";".stripslashes($this->output_codage_caractere($description_competence)).";$ref_domaine;$num_competence;$nb_item_competences\n";
			
			// ITEM
			$compteur_item=0;
			$records_items = referentiel_get_item_competences($competence->id);
			
			if ($records_items){
				// DEBUG
				// echo "<br/>DEBUG :: ITEMS <br />\n";
				// print_r($records_items);
				$expout .= "#id_item;code_item;description_item;ref_referentiel;ref_competence;type_item;poids_item;num_item\n";				
				foreach ($records_items as $record_i){
					// DEBUG
					// echo "<br/>DEBUG :: ITEM <br />\n";
					// print_r($record_i);
					$expout .= $this->write_item( $record_i );
				}
			}
        }
        return $expout;
    }


	 /**
     * Turns domaine into an xml segment
     * @param domaine object
     * @return string xml segment
     */

    function write_domaine( $domaine ) {
    global $CFG;
        // initial string;
        $expout = "#domaine_id;code;description;ref_referentiel;num_domaine;nb_competences\n";
        // add comment		
		if ($domaine){
            $code = $domaine->code_domaine;
            $description_domaine = $domaine->description_domaine;
            $ref_referentiel = $domaine->ref_referentiel;
			$num_domaine = $domaine->num_domaine;
			$nb_competences = $domaine->nb_competences;			
			$expout .= stripslashes($this->output_codage_caractere($code)).";".stripslashes($this->output_codage_caractere($description_domaine)).";$ref_referentiel;$num_domaine;$nb_competences\n";
			
			// LISTE DES COMPETENCES DE CE DOMAINE
			$compteur_competence=0;
			$records_competences = referentiel_get_competences($domaine->id);
			if ($records_competences){
				// DEBUG
				// echo "<br/>DEBUG :: COMPETENCES <br />\n";
				// print_r($records_competences);
				foreach ($records_competences as $record_c){
					$expout .= "#id_competence;code_competence;description_competence;num_competence;nb_item_competences\n";								
					$expout .= $this->write_competence( $record_c );
				}
			}
        }
        return $expout;
    }



	 /**
     * Turns referentiel into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_referentiel( $referentiel ) {
    	global $CFG;
        // initial string;
		$expout ="";
		if ($referentiel){
			$id = $referentiel->id;
            $name = $referentiel->name;
            $code_referentiel = $referentiel->code_referentiel;
            $description_referentiel = $referentiel->description_referentiel;
            $url_referentiel = $referentiel->url_referentiel;
			$seuil_certificat = $referentiel->seuil_certificat;
			$timemodified = $referentiel->timemodified;			
			$nb_domaines = $referentiel->nb_domaines;
			$liste_codes_competence = $referentiel->liste_codes_competence;
			$liste_empreintes_competence = $referentiel->liste_empreintes_competence;
			$local = $referentiel->local;
        	
			// $expout = "#Referentiel : ".$referentiel->id." : ".stripslashes($this->output_codage_caractere($referentiel->name))."\n";
    		// add header
    		$expout .= "#id_referentiel;name;code_referentiel;description_referentiel;url_referentiel;seuil_certificat;timemodified;nb_domaines;liste_codes_competences;liste_empreintes_competences;local\n";
			$expout .= "$id;".stripslashes($this->output_codage_caractere($name)).";".stripslashes($this->output_codage_caractere($code_referentiel)).";".stripslashes($this->output_codage_caractere($description_referentiel)).";$url_referentiel;$seuil_certificat;".referentiel_timestamp_date_special($timemodified).";$nb_domaines;".stripslashes($this->output_codage_caractere($liste_codes_competence)).";".stripslashes($this->output_codage_caractere($liste_empreintes_competence)).";$local\n";
			
			// DOMAINES
			if (isset($referentiel->id) && ($referentiel->id>0)){
				// LISTE DES DOMAINES
				$compteur_domaine=0;
				$records_domaine = referentiel_get_domaines($referentiel->id);
		    	if ($records_domaine){
    				// afficher
					// DEBUG
					// echo "<br/>DEBUG ::<br />\n";
					// print_r($records_domaine);
					foreach ($records_domaine as $record_d){
						// DEBUG
						// echo "<br/>DEBUG ::<br />\n";
						// print_r($records_domaine);
						$expout .= $this->write_domaine( $record_d );
					}
				}
			} 
        }
        return $expout;
    }

	function write_etablissement( $record ) {
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\netablissement: $record->id\n";
		if ($record){
			// $expout .= "#id_etablissement;num_etablissement;nom_etablissement;dresse_etablissement\n";
			$id = trim( $record->id );
			$num_etablissement = trim( $record->num_etablissement);
			$nom_etablissement = trim( $record->nom_etablissement);
			$adresse_etablissement = trim( $record->adresse_etablissement);
			
			$expout .= "$id;$num_etablissement;".stripslashes($this->output_codage_caractere($nom_etablissement)).";".stripslashes($this->output_codage_caractere($adresse_etablissement))."\n";
        }
        return $expout;
    }

    function write_liste_etablissements() {
    	global $CFG;
        // initial string;
        $expout = ""; 
		// ETABLISSEMENTS
		$records_all_etablissements = referentiel_get_etablissements();
		if ($records_all_etablissements){
			$expout .= "#id_etablissement;num_etablissement;nom_etablissement;adresse_etablissement\n";		
			foreach ($records_all_etablissements as $record){
				if ($record){
					$expout.=$this->write_etablissement($record);
				}
			}
        }
        return $expout;
    }

	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certificat( $record ) {
    	global $CFG;
        // initial string;
        $expout = "";
    	// $expout .= "\ncertificat : $record->id\n";
		// USER
		if ($record){
			//$expout .= "#id_etudiant;user_id;login;Prenom;NOM;num_etudiant;ddn_etudiant;lieu_naissance;departement_naissance;adresse_etudiant;ref_etablissement;id_certificat;commentaire_certificat;competences_certificat;decision_jury;date_decision;ref_referentiel;verrou;valide;evaluation\n";
			$ok_etudiant=false;
			
			$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    if ($record_etudiant){
					$id_etudiant = trim($record_etudiant->id );
		            $ref_etablissement = trim($record_etudiant->ref_etablissement);
					$num_etudiant = trim($record_etudiant->num_etudiant);
					$ddn_etudiant = trim($record_etudiant->ddn_etudiant);
					$lieu_naissance = trim($record_etudiant->lieu_naissance);
					$departement_naissance = trim($record_etudiant->departement_naissance);
					$adresse_etudiant = trim($record_etudiant->adresse_etudiant);			
		    		$expout .= "$id_etudiant;".$record->userid.";".$this->output_codage_caractere(referentiel_get_user_login($record->userid)).";".referentiel_get_user_prenom($record->userid).";".referentiel_get_user_nom($record->userid).";$num_etudiant;$ddn_etudiant;".stripslashes($this->output_codage_caractere($lieu_naissance)).";".stripslashes($this->output_codage_caractere($departement_naissance)).";".stripslashes($this->output_codage_caractere($adresse_etudiant)).";$ref_etablissement;"; 
					$ok_etudiant=true;
			}
			if ($ok_etudiant==false){
		    	$expout .= ";".$record->userid.";;;;;;;;";
			}
			
			// DEBUG
			// echo "<br />DEBUG LIGNE 1021<br />\n";
			// print_r($referentiel_instance);
			$id = trim( $record->id );
            $commentaire_certificat = trim($record->commentaire_certificat);
            $competences_certificat =  trim($record->competences_certificat) ;
            $decision_jury = trim($record->decision_jury);
            $date_decision = trim($record->date_decision);
            $userid = trim( $record->userid);
            $teacherid = trim( $record->teacherid);
            $ref_referentiel = trim( $record->ref_referentiel);
			$verrou = trim( $record->verrou );
			$valide = trim( $record->valide );
			$evaluation = trim( $record->evaluation );
            $expout .= "$id;".stripslashes($this->output_codage_caractere($commentaire_certificat)).";".stripslashes($this->output_codage_caractere($competences_certificat)).";".stripslashes($this->output_codage_caractere($decision_jury)).";".referentiel_timestamp_date_special($date_decision).";$ref_referentiel;$verrou;$valide;$evaluation\n";
        }
		
        return $expout;
    }

	
	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
		// 
		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = trim($referentiel_instance->name);
            $description_instance = trim($referentiel_instance->description_instance);
            $label_domaine = trim($referentiel_instance->label_domaine);
            $label_competence = trim($referentiel_instance->label_competence);
            $label_item = trim($referentiel_instance->label_item);
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;
			
			// $expout .= "#Instance de referentiel : $referentiel_instance->name\n";
			$expout .= "#id_instance;name;description_instance;label_domaine;label_competence;label_item;date_instance;course;ref_referentiel;visible\n";
			$expout .= "$id;".stripslashes($this->output_codage_caractere($name)).";".stripslashes($this->output_codage_caractere($description_instance)).";".stripslashes($this->output_codage_caractere($label_domaine)).";".stripslashes($this->output_codage_caractere($label_competence)).";".stripslashes($this->output_codage_caractere($label_item)).";".referentiel_timestamp_date_special($date_instance).";$course;$ref_referentiel;$visible\n";
			
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				$record_referentiel = referentiel_get_referentiel_referentiel($referentiel_instance->ref_referentiel);
				$expout .= $this->write_referentiel($record_referentiel);
				$expout .= $this->write_liste_etablissements($record_referentiel);
				
				$records_certificats = referentiel_get_certificats($referentiel_instance->ref_referentiel);
		    	if ($records_certificats){
					$expout .= "#id_etudiant;user_id;login;Prenom;NOM;num_etudiant;ddn_etudiant;lieu_naissance;departement_naissance;adresse_etudiant;ref_etablissement;id_certificat;commentaire_certificat;competences_certificat;decision_jury;date_decision;ref_referentiel;verrou;valide;evaluation\n";
					foreach ($records_certificats as $record){
						$expout .= $this->write_certificat( $record );
					}
				}
			}
        }
        return $expout;
    }
}

// ################################################################################################################
// ETUDIANTS : export des etudiants
class eformat_csv extends eformat_default {
	var $sep = ";";
	
	var $table_caractere_input='latin1'; // par defaut import latin1
	var $table_caractere_output='latin1'; // par defaut export latin1
	
	// ----------------
	function recode_latin1_vers_utf8($s0){
	// retourne une chaine recode latin1
    	if (is_string($s0)){
	    // �����
    	// ëçöùñ
                    $s0=ereg_replace( "�", "é", $s0);
                    $s0=ereg_replace( "�", "è", $s0);
                    $s0=ereg_replace( "�", "ê", $s0);
                    $s0=ereg_replace( "�", "ë", $s0);
					$s0=ereg_replace( "�", "î", $s0);
                    $s0=ereg_replace( "�", "ï", $s0);
                    $s0=ereg_replace( "�", "à", $s0);
                    $s0=ereg_replace( "�", "ô", $s0);
                    $s0=ereg_replace( "�", "ö", $s0);
                    $s0=ereg_replace( "�", "ç", $s0);
                    $s0=ereg_replace( "�", "ù", $s0);
                    $s0=ereg_replace( "�", "ñ", $s0);
    	}
		return $s0;
	}


	// ----------------
	function recode_utf8_vers_latin1($s0){
	// retourne une chaine recode latin1
	
	    if (is_string($s0) && ereg("�", $s0)){
    		// �����
		    // ëçöùñ
                    $s0=ereg_replace( "é", "�", $s0 );
                    $s0=ereg_replace( "è", "�", $s0 );
                    $s0=ereg_replace( "ê", "�", $s0 );
                    $s0=ereg_replace( "ë", "�", $s0 );
					$s0=ereg_replace( "î", "�", $s0);
                    $s0=ereg_replace( "ï", "�", $s0);
                    $s0=ereg_replace( "à", "�", $s0);
                    $s0=ereg_replace( "ô", "�", $s0);
                    $s0=ereg_replace( "ö", "�", $s0);
                    $s0=ereg_replace( "ç", "�", $s0);
                    $s0=ereg_replace( "ù", "�", $s0);
                    $s0=ereg_replace( "ñ", "�", $s0);
    	}
		return $s0;
	}

	 /**
     * @param 
     * @return string recode latin1
	 * 
     */
    function input_codage_caractere($s){
		if (!isset($this->table_caractere_input) || ($this->table_caractere_input=="")){
			$this->table_caractere_input='latin1';
		}
		
		if ($this->table_caractere_input=='latin1'){
			$s=$this->recode_latin1_vers_utf8($s);
		}
		return $s;
	}
	
	 /**
     * @param 
     * @return string recode utf8
	 * 
     */
    function output_codage_caractere($s){
		if (!isset($this->table_caractere_output) || ($this->table_caractere_output=="")){
			$this->table_caractere_output='latin1';
		}
		
		if ($this->table_caractere_output=='latin1'){
			$s=$this->recode_utf8_vers_latin1($s);
		}
		return $s;
	}



    function provide_export() {
      return true;
    }

	function provide_import() {
        return true;
    }

	function repchar( $text ) {
	    // escapes 'reserved' characters # = ~ { ) and removes new lines
    	$reserved = array( '#','=','~','{','}',"\n","\r" );
	    $escaped = array( '\#','\=','\~','\{','\}',' ','' );
		return str_replace( $reserved, $escaped, $text ); 
	}

	function presave_process( $content ) {
	  // override method to allow us to add xhtml headers and footers
  		global $CFG;
		$xp =  "#Moodle Referentiel Students CSV Export;latin1;".referentiel_timestamp_date_special(time())."\n";
		$xp .= $content;
  		return $xp;
	}

	function export_file_extension() {
  		return ".csv";
	}

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	
	/**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function write_ligne( $raw, $sep="/", $nmaxcar=80) {
        // insere un saut de ligne apres le 80 caracter 
		$nbcar=strlen($raw);
		if ($nbcar>$nmaxcar){
			$s1=substr( $raw,0,$nmaxcar);
			$pos1=strrpos($s1,$sep);
			if ($pos1>0){
				$s1=substr( $raw,0,$pos1);
				$s2=substr( $raw,$pos1+1);
			}
			else {
				$s1=substr( $raw,0,$nmaxcar);
				$s2=substr( $raw,$nmaxcar);
			}
		    return $s1." ".$s2;
		}
		else{
			return $raw;
		}
    }


	function write_etablissement($record) {
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\netablissement: $record->id\n";
		if ($record){
			//$expout .= "#id_etablissement;num_etablissement;nom_etablissement;adresse_etablissement\n";
			$id = trim( $record->id );
			$num_etablissement = trim( $record->num_etablissement);
			$nom_etablissement = $this->output_codage_caractere(trim( $record->nom_etablissement));
			$adresse_etablissement = $this->output_codage_caractere(trim( $record->adresse_etablissement));
			$logo = trim( $record->logo_etablissement);
			
			$expout .= "$id;$num_etablissement;$nom_etablissement;$adresse_etablissement\n";
        }
        return $expout;
    }


	function write_etudiant( $record ) {
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\netudiant: $record->id  -->\n";
		if ($record){
			$id = trim( $record->id );
			$userid = trim( $record->userid );
            $ref_etablissement = trim( $record->ref_etablissement);
			$num_etudiant = trim( $record->num_etudiant);
			$ddn_etudiant = trim( $record->ddn_etudiant);
			$lieu_naissance = $this->output_codage_caractere(trim( $record->lieu_naissance));
			$departement_naissance = $this->output_codage_caractere(trim( $record->departement_naissance));
			$adresse_etudiant = $this->output_codage_caractere(trim( $record->adresse_etudiant));			
    		$expout .= "$id;$userid;".$this->output_codage_caractere(referentiel_get_user_login($record->userid)).";".$this->output_codage_caractere(referentiel_get_user_prenom($record->userid)).";".$this->output_codage_caractere(referentiel_get_user_nom($record->userid)).";$num_etudiant;$ddn_etudiant;$lieu_naissance;$departement_naissance;$adresse_etudiant;$ref_etablissement\n"; 
/*
			// Etablissement
			$record_etablissement=referentiel_get_etablissement($record->ref_etablissement);
	    	if ($record_etablissement){
				$expout .= $this->write_etablissement( $record_etablissement );
			}
*/
        }
        return $expout;
    }

	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_liste_etudiants( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = ""; 

		if ($referentiel_instance){
			$id = $referentiel_instance->id;
            $name = $this->output_codage_caractere(trim($referentiel_instance->name));
            $description_instance = $this->output_codage_caractere(trim($referentiel_instance->description_instance));
            $label_domaine = $this->output_codage_caractere(trim($referentiel_instance->label_domaine));
            $label_competence = $this->output_codage_caractere(trim($referentiel_instance->label_competence));
            $label_item = $this->output_codage_caractere(trim($referentiel_instance->label_item));
            $date_instance = $referentiel_instance->date_instance;
            $course = $referentiel_instance->course;
            $ref_referentiel = $referentiel_instance->ref_referentiel;
			$visible = $referentiel_instance->visible;
			
//			$expout .= "Instance de referentiel : $referentiel_instance->name\n";
//			$expout .= "id;name;description_instance;label_domaine;label_competence;label_item;date_instance;course;ref_referentiel;visible\n";
//			$expout .= "$id;$name;$description_instance;$label_domaine;$label_competence;$label_item;$date_instance;$course;$ref_referentiel;$visible\n";
			
			if (isset($referentiel_instance->course) && ($referentiel_instance->course>0)){
				// ETUDIANTS
				$records_all_students = referentiel_get_students_course($referentiel_instance->course);
				if ($records_all_students){
				    $expout .= "#id_etudiant;user_id;login;Prenom;NOM;num_etudiant;ddn_etudiant;lieu_naissance;departement_naissance;adresse_etudiant;ref_etablissement\n"; 
					foreach ($records_all_students as $record){
						// USER
						if (isset($record->userid) && ($record->userid>0)){
							$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    				if ($record_etudiant){
								$expout .= $this->write_etudiant( $record_etudiant );
							}
						}
					}
				}
			}
        }
        return $expout;
    }

    function write_liste_etablissements() {
    	global $CFG;
        // initial string;
        $expout = ""; 
		// ETABLISSEMENTS
		$records_all_etablissements = referentiel_get_etablissements();
		if ($records_all_etablissements){
			$expout .= "#id_etablissement;num_etablissement;nom_etablissement;adresse_etablissement\n";		
			foreach ($records_all_etablissements as $record){
				if ($record){
					$expout.=$this->write_etablissement($record);
				}
			}
        }
        return $expout;
    }

	// IMPORTATION
	/***************************************************************************
		
	// IMPORT FUNCTIONS START HERE
	
	***************************************************************************/
     /**
	 * @param array referentiel array from xml tree
     * @return object import_referentiel object
	 * modifie la base de donnees 
     */
    function importation_referentiel_possible(){
	// selon les parametres soit cree une nouvelle instance 
	// soit modifie une instance courante de referentiel
	global $CFG;
		
		if (!isset($this->action) || (isset($this->action) && ($this->action!="selectreferentiel") && ($this->action!="importreferentiel"))){
			if (!(isset($this->course->id) && ($this->course->id>0)) 
				|| 
				!(isset($this->rreferentiel->id) && ($this->rreferentiel->id>0))
				|| 
				!(isset($this->coursemodule->id) && ($this->coursemodule->id>0))
				){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="selectreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="importreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		return true;
	}
	
	
     /**
	 * @param array referentiel array from xml tree
     * @return object import_referentiel object
	 * modifie la base de donnees 
     */
    function import_etablissements_etudiants( $lines ) {
	// recupere le tableau de lignes 
	// selon les parametres soit cree une nouvelle instance 
	// soit modifie une instance courante de students
	global $SESSION;
	global $USER;
	global $CFG;
	
	// initialiser les variables	
	$date_creation="";
	$in_etablissement=false; // drapeau
	$in_etudiant=false;		// drapeau
		
    // get some error strings
    $error_noname = get_string( 'xmlimportnoname', 'referentiel' );
    $error_nocode = get_string( 'xmlimportnocode', 'referentiel' );
	$error_override = get_string( 'overriderisk', 'referentiel' );
	
	// DEBUT	
	// Decodage 
	$line = 0;
	// TRAITER LA LIGNE D'ENTETE
	$nbl=count($lines);
	if ($nbl>0){ // premiere ligne entete fichier csv
		// echo "<br>$line : ".$lines[$line]."\n";
		//"#Moodle Referentiel Students CSV Export;latin1;Y:2009m:06d:11\n"
		
        $fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
	  	$line++;
		if (substr($lines[$line],0,1)=='#'){
			// labels			
	        /// If a line is incorrectly formatted 
            if (count($fields) < 3 ) {
	           	if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
					$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted - ignoring\n");
				}
           	}
			if (isset($fields[1]) && ($fields[1]!="")){
		        $this->table_caractere_input=trim($fields[1]);
			}
			$date_creation=trim($fields[2]);
		}
	}
	else{
		$this->error("ERROR : CSV File incorrect\n");
	}
	// echo "<br />DEBUG :: 2073 : $this->table_caractere_input\n";
	
	if ($nbl>1){ // deuxieme ligne : entete etablissment
		// echo "<br>$line : ".$lines[$line]."\n";
		while ($line<$nbl){ // data : referentiel		
			// #id_etablissement;num_etablissement;nom_etablissement;adresse_etablissement
			// 
        	$fields = explode($this->sep, str_replace( "\r", "", $lines[$line] ) );
        	/// If a line is incorrectly formatted 
        	if (count($fields) < 3 ) {
           		if ( count($fields) > 1 or strlen($fields[0]) > 1) { // no error for blank lines
					$this->error("ERROR ".$lines[$line].": Line ".$line."incorrectly formatted");
    			}
			}
			else{
				if (substr($lines[$line],0,1)=='#'){
					// labels
    		    	$l_id = trim($fields[0]);
					if ($l_id=="#id_etablissement"){
						$l_id_etablissement = trim($fields[0]);
						$l_num_etablissement = trim($fields[1]);
		        		$l_nom_etablissement = trim($fields[2]);
						$l_adresse_etablissement = trim($fields[3]);
						if (isset($fields[4]))
							$l_logo_etablissement = trim($fields[4]);
						else
							$l_logo_etablissement = "";
						$in_etablissement=true;
						$in_etudiant=false;
					}
					else if ($l_id=="#id_etudiant"){
						// #id_etudiant;user_id;login;NOM_Prenom;num_etudiant;ddn_etudiant;lieu_naissance;departement_naissance;adresse_etudiant;ref_etablissement
						$l_id_etudiant = trim($fields[0]);
						$l_user_id = trim($fields[1]);
						$l_login = trim($fields[2]);
						$l_Prenom = trim($fields[3]);
				        $l_NOM = trim($fields[4]);
						$l_num_etudiant = trim($fields[5]);
						$l_ddn_etudiant = trim($fields[6]);
						$l_lieu_naissance = trim($fields[7]);
						$l_departement_naissance = trim($fields[8]);
						$l_adresse_etudiant = trim($fields[9]);
						$l_ref_etablissement = trim($fields[10]);
						
						$in_etablissement=false;
						$in_etudiant=true;
					}
				}
				else{
					// data  : 
		    		if ($in_etablissement==true){ // etablissement
						$id_etablissement = trim($fields[0]);
						$num_etablissement = $this->input_codage_caractere(trim($fields[1]));
				        $nom_etablissement = $this->input_codage_caractere(trim($fields[2]));
						$adresse_etablissement = $this->input_codage_caractere(trim($fields[3]));
						if (isset($fields[4]))
							$logo_etablissement = trim($fields[4]);
						else
							$logo_etablissement = "";
						
						// this routine initialises the import object
				        $import_etablissement = new stdClass();
						$import_etablissement->id=0;
						$import_etablissement->num_etablissement=$num_etablissement;
						$import_etablissement->nom_etablissement=str_replace("'", " ",$nom_etablissement);
						$import_etablissement->adresse_etablissement=str_replace("'", " ",$adresse_etablissement);
						$import_etablissement->logo_etablissement=$logo_etablissement;
						// sauvegarde dans la base
						if ($id_etablissement==0){
							$new_etablissement_id=insert_record("referentiel_etablissement", $import_etablissement);
						}
						else{
							$import_etablissement->id=$id_etablissement;
							if (!update_record("referentiel_etablissement", $import_etablissement)){
								// DEBUG
								// echo "<br /> ERREUR UPDATE etablissement\n";
							}
						}
					}
					elseif ($in_etudiant==true){ // etudiant
						$id_etudiant = trim($fields[0]);
						$user_id = $this->input_codage_caractere(trim($fields[1]));
						$login = $this->input_codage_caractere(trim($fields[2]));
			        	$Prenom = $this->input_codage_caractere(trim($fields[3]));
						$NOM = $this->input_codage_caractere(trim($fields[4]));
						$num_etudiant = $this->input_codage_caractere(trim($fields[5]));
						$ddn_etudiant = trim($fields[6]);
						$lieu_naissance = $this->input_codage_caractere(trim($fields[7]));
						$departement_naissance = $this->input_codage_caractere(trim($fields[8]));
						$adresse_etudiant = $this->input_codage_caractere(trim($fields[9]));
						$ref_etablissement = trim($fields[10]);
						// rechercher l'id 
						if (($id_etudiant=='') || ($id_etudiant==0)){
							if (($user_id!='') && ($user_id>0)){
								// rechercher l'id s'il existe
								$id_etudiant=referentiel_get_etudiant_id_by_userid($user_id);
							}
							else if ($login!=''){
								$id_etudiant=referentiel_get_etudiant_id_by_userid(referentiel_get_userid_by_login($login));
							}
						}
						// this routine initialises the import object
				        $import_etudiant = new stdClass();
						$import_etudiant->id=0;
						$import_etudiant->num_etudiant=$num_etudiant;
						$import_etudiant->adresse_etudiant=str_replace("'", " ",$adresse_etudiant);
						$import_etudiant->ddn_etudiant = $ddn_etudiant ;
						$import_etudiant->lieu_naissance =$lieu_naissance;
						$import_etudiant->departement_naissance = $departement_naissance;
						$import_etudiant->ref_etablissement = $ref_etablissement;
						$import_etudiant->userid = $user_id;
						
						// sauvegarde dans la base
						if ($id_etudiant==0){
							$new_etudiant_id=insert_record("referentiel_etudiant", $import_etudiant);
						}
						else{
							$import_etudiant->id=$id_etudiant;
							if (!update_record("referentiel_etudiant", $import_etudiant)){
								// DEBUG
								// echo "<br /> ERREUR UPDATE etudiant\n";
							}
						}
					}
				}
			}
			$line++;
		}
	}
	return true;
}


    /**
     * parse the array of lines into an array 
     * this *could* burn memory - but it won't happen that much
     * so fingers crossed!
     * @param array lines array of lines from the input file
     * @return array of student object
     */
	function read_import_students($lines) {
        // we just need it as one array
		return $this->import_etablissements_etudiants($lines);
    }

}


?>
