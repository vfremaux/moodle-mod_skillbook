<?php // $Id: format.php,v 1.21.2.16 2008/01/15 14:58:10 thepurpleblob Exp $
//
///////////////////////////////////////////////////////////////
// XML import/export
//
//////////////////////////////////////////////////////////////////////////
// Based on default.php, included by ../import.php
/**
 * @package referetielbank
 * @subpackage importexport
 */
require_once( "$CFG->libdir/xmlize.php" );

class rformat_xml extends rformat_default {

    function provide_import() {
        return true;
    }

    function provide_export() {
        return true;
    }


    // EXPORT FUNCTIONS START HERE

    function export_file_extension() {
    // override default type so extension is .xml
        return ".xml";
    }


    /**
     * Convert internal Moodle text format code into
     * human readable form
     * @param int id internal code
     * @return string format text
     */
    function get_format( $id ) {
        switch( $id ) {
        case 0:
            $name = "moodle_auto_format";
            break;
        case 1:
            $name = "html";
            break;
        case 2:
            $name = "plain_text";
            break;
        case 3:
            $name = "wiki_like";
            break;
        case 4:
            $name = "markdown";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * Convert internal single question code into 
     * human readable form
     * @param int id single question code
     * @return string single question string
     */
    function get_single( $id ) {
        switch( $id ) {
        case 0:
            $name = "false";
            break;
        case 1:
            $name = "true";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function writetext( $raw, $ilev=0, $short=true) {
        $indent = str_repeat( "  ",$ilev );

        // encode the text to 'disguise' HTML content 
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
		
        $raw = htmlspecialchars( $raw );

        if ($short) {
            $xml = "$indent<text>$raw</text>\n";
        }
        else {
            $xml = "$indent<text>\n$raw\n$indent</text>\n";
        }

        return $xml;
    }

    /**
     * generates raw text therein 
     * @return string not formatted text
     */

    function writeraw( $raw) {
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
	    return $raw;
    }
  
    function xmltidy( $content ) {
        // can only do this if tidy is installed
        if (extension_loaded('tidy')) {
            $config = array( 'input-xml'=>true, 'output-xml'=>true, 'indent'=>true, 'wrap'=>0 );
            $tidy = new tidy;
            $tidy->parseString($content, $config, 'utf8');
            $tidy->cleanRepair(); 
            return $tidy->value;
        }
        else {
            return $content;
        }
    }


    function presave_process( $content ) {
    // override method to allow us to add xml headers and footers

        // add the xml headers and footers
        $content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
                       "<referentiel>\n" .
                       $content .
                       "</referentiel>\n\n";

        // make the xml look nice
        $content = $this->xmltidy( $content );

        return $content;
    }

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

    /**
     * Turns item into an xml segment
     * @param item object
     * @return string xml segment
     */

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
        // $expout .= "\n\n<!-- item: $item->id  -->\n";
		// 
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
			$id = $this->writeraw( $item->id );
            $code = $this->writeraw( trim($item->code_item));
            $description_item = $this->writetext(trim($item->description_item));
            $ref_referentiel = $this->writeraw( $item->ref_referentiel);
            $ref_competence = $this->writeraw( $item->ref_competence);
			$type_item = $this->writeraw( trim($item->type_item));
			$poids_item = $this->writeraw( $item->poids_item);
			$empreinte_item = $this->writeraw( $item->empreinte_item);
			$num_item = $this->writeraw( $item->num_item);
            $expout .= "   <item>\n";
			// $expout .= "    <id>$id</id>\n";
			$expout .= "    <code>$code</code>\n";
            $expout .= "    <description_item>\n$description_item</description_item>\n";
            // $expout .= "    <ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            // $expout .= "    <ref_competence>$ref_competence</ref_competence>\n";
            $expout .= "    <type_item>$type_item</type_item>\n";
            $expout .= "    <poids_item>$poids_item</poids_item>\n";
            $expout .= "    <empreinte_item>$empreinte_item</empreinte_item>\n";			
            $expout .= "    <num_item>$num_item</num_item>\n";
			$expout .= "   </item>\n\n";
        }
        return $expout;
    }

	 /**
     * Turns competence into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_competence( $competence ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        // $expout .= "\n\n<!-- competence: $competence->id  -->\n";
		//
		if ($competence){
			$id = $this->writeraw( $competence->id );		
            $code = $this->writeraw( trim($competence->code_competence));
            $description_competence = $this->writetext(trim($competence->description_competence));
            $ref_domaine = $this->writeraw( $competence->ref_domaine);
			$num_competence = $this->writeraw( $competence->num_competence);
			$nb_item_competences = $this->writeraw( $competence->nb_item_competences);
			
            $expout .= "  <competence>\n";
			// $expout .= "<id>$id</id>\n";
			$expout .= "   <code_competence>$code</code_competence>\n";   
            $expout .= "   <description_competence>\n$description_competence</description_competence>\n";
            // $expout .= "   <ref_domaine>$ref_domaine</ref_domaine>\n";
            $expout .= "   <num_competence>$num_competence</num_competence>\n";
            $expout .= "   <nb_item_competences>$nb_item_competences</nb_item_competences>\n\n";
							
			// ITEM
			$compteur_item=0;
			$records_items = referentiel_get_item_competences($competence->id);
			
			if ($records_items){
				// DEBUG
				// echo "<br/>DEBUG :: ITEMS <br />\n";
				// print_r($records_items);
				foreach ($records_items as $record_i){
					// DEBUG
					// echo "<br/>DEBUG :: ITEM <br />\n";
					// print_r($record_i);
					$expout .= $this->write_item( $record_i );
				}
			}
			$expout .= "  </competence>\n\n";   
        }
        return $expout;
    }


	 /**
     * Turns domaine into an xml segment
     * @param domaine object
     * @return string xml segment
     */

    function write_domaine( $domaine ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        // $expout .= "\n\n<!-- domaine: $domaine->id  -->\n";
		// 
		if ($domaine){
			$id = $this->writeraw( $domaine->id );
            $code = $this->writeraw( trim($domaine->code_domaine) );
            $description_domaine = $this->writetext(trim($domaine->description_domaine));
            $ref_referentiel = $this->writeraw( $domaine->ref_referentiel );
			$num_domaine = $this->writeraw( $domaine->num_domaine );
			$nb_competences = $this->writeraw( $domaine->nb_competences );
			
            $expout .= " <domaine>\n";
			// $expout .= "  <id>$id</id>\n";
			$expout .= "  <code_domaine>$code</code_domaine>\n";   
            $expout .= "  <description_domaine>\n$description_domaine</description_domaine>\n";
            // $expout .= " <ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "  <num_domaine>$num_domaine</num_domaine>\n";
            $expout .= "  <nb_competences>$nb_competences</nb_competences>\n\n";
			
			// LISTE DES COMPETENCES DE CE DOMAINE
			$compteur_competence=0;
			$records_competences = referentiel_get_competences($domaine->id);
			if ($records_competences){
				// DEBUG
				// echo "<br/>DEBUG :: COMPETENCES <br />\n";
				// print_r($records_competences);
				foreach ($records_competences as $record_c){
					$expout .= $this->write_competence( $record_c );
				}
			}
			$expout .= " </domaine>\n\n";   
        }
        return $expout;
    }



	 /**
     * Turns referentiel into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_referentiel( $referentiel ) {
    	global $CFG;
        // initial string;
        $expout = "";
        // add comment		
		// 
		if ($referentiel){
			$id = $this->writeraw( $referentiel->id );
            $name = $this->writeraw( trim($referentiel->name) );
            $code_referentiel = $this->writeraw( trim($referentiel->code_referentiel));
            $description_referentiel = $this->writetext(trim($referentiel->description_referentiel));
            $url_referentiel = $this->writeraw( trim($referentiel->url_referentiel) );
			$seuil_certificat = $this->writeraw( $referentiel->seuil_certificat );
			$timemodified = $this->writeraw( $referentiel->timemodified );			
			$nb_domaines = $this->writeraw( $referentiel->nb_domaines );
			$liste_codes_competence = $this->writeraw( trim($referentiel->liste_codes_competence) );
			$liste_empreintes_competence = $this->writeraw( trim($referentiel->liste_empreintes_competence) );			
			$local = $this->writeraw( $referentiel->local );
			$logo_referentiel = $this->writeraw( $referentiel->logo_referentiel );
			
			// $expout .= "<id>$id</id>\n";
			$expout .= " <name>$name</name>\n";   
			$expout .= " <code_referentiel>$code_referentiel</code_referentiel>\n";   
            $expout .= " <description_referentiel>\n$description_referentiel</description_referentiel>\n";
            $expout .= " <url_referentiel>$url_referentiel</url_referentiel>\n";
            $expout .= " <seuil_certificat>$seuil_certificat</seuil_certificat>\n";
            $expout .= " <timemodified>$timemodified</timemodified>\n";			
            $expout .= " <nb_domaines>$nb_domaines</nb_domaines>\n";
            $expout .= " <liste_codes_competence>$liste_codes_competence</liste_codes_competence>\n";
            $expout .= " <liste_empreintes_competence>$liste_empreintes_competence</liste_empreintes_competence>\n";
			// $expout .= " <local>$local</local>\n";
			// PAS DE LOGO ICI
			// $expout .= " <logo_referentiel>$logo_referentiel</logo_referentiel>\n";
			
			// DOMAINES
			if (isset($referentiel->id) && ($referentiel->id>0)){
				// LISTE DES DOMAINES
				$compteur_domaine=0;
				$records_domaine = referentiel_get_domaines($referentiel->id);
		    	if ($records_domaine){
    				// afficher
					// DEBUG
					// echo "<br/>DEBUG ::<br />\n";
					// print_r($records_domaine);
					foreach ($records_domaine as $record_d){
						// DEBUG
						// echo "<br/>DEBUG ::<br />\n";
						// print_r($records_domaine);
						$expout .= $this->write_domaine( $record_d );
					}
				}
			}
        }
        return $expout;
    }



    // IMPORT FUNCTIONS START HERE

    /** 
     * Translate human readable format name
     * into internal Moodle code number
     * @param string name format name from xml file
     * @return int Moodle format code
     */
    function trans_format( $name ) {
        $name = trim($name); 
 
        if ($name=='moodle_auto_format') {
            $id = 0;
        }
        elseif ($name=='html') {
            $id = 1;
        }
        elseif ($name=='plain_text') {
            $id = 2;
        }
        elseif ($name=='wiki_like') {
            $id = 3;
        }
        elseif ($name=='markdown') {
            $id = 4;
        }
        else {
            $id = 0; // or maybe warning required
        }
        return $id;
    }

    /**
     * Translate human readable single answer option
     * to internal code number
     * @param string name true/false
     * @return int internal code number
     */
    function trans_single( $name ) {
        $name = trim($name);
        if ($name == "false" || !$name) {
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * process text string from xml file
     * @param array $text bit of xml tree after ['text']
     * @return string processed text
     */
    function import_text( $text ) {
        // quick sanity check
        if (empty($text)) {
            return '';
        }
        $data = $text[0]['#'];
        return addslashes(trim( $data ));
    }

    /**
     * return the value of a node, given a path to the node
     * if it doesn't exist return the default value
     * @param array xml data to read
     * @param array path path to node expressed as array 
     * @param mixed default 
     * @param bool istext process as text
     * @param string error if set value must exist, return false and issue message if not
     * @return mixed value
     */
    function getpath( $xml, $path, $default, $istext=false, $error='' ) {
        foreach ($path as $index) {
			// echo " $index ";
            if (!isset($xml[$index])) {
                if (!empty($error)) {
                    $this->error( $error );
                    return false;
                } else {
					// echo " erreur ";
                    return $default;
                }
            }
            else {
				$xml = $xml[$index];
				// echo " $xml ";
			}
        }
        if ($istext) {
            $xml = addslashes( trim( $xml ) );
        }
		
        return $xml;
    }


    /**
     * @param array referentiel array from xml tree
     * @return object import_referentiel object
	 * modifie la base de donnees 
     */
    function import_referentiel( $xmlreferentiel ) {
	// recupere le fichier xml 
	// selon les parametres soit cree une nouvelle instance 
	// soit modifie une instance courante de referentiel
	global $SESSION;
	global $USER;
	global $CFG;
		// print_r($xmlreferentiel);
		if (!isset($this->action) || (isset($this->action) && ($this->action!="selectreferentiel") && ($this->action!="importreferentiel"))){
			if (!(isset($this->course->id) && ($this->course->id>0)) 
				|| 
				!(isset($this->rreferentiel->id) && ($this->rreferentiel->id>0))
				|| 
				!(isset($this->coursemodule->id) && ($this->coursemodule->id>0))
				){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="selectreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		else if (isset($this->action) && ($this->action=="importreferentiel")){
			if (!(isset($this->course->id) && ($this->course->id>0))){
				$this->error( get_string( 'incompletedata', 'referentiel' ) );
				return false;
			}
		}
		
		$risque_ecrasement=false;
		
        // get some error strings
        $error_noname = get_string( 'xmlimportnoname', 'referentiel' );
        $error_nocode = get_string( 'xmlimportnocode', 'referentiel' );
		$error_override = get_string( 'overriderisk', 'referentiel' );
		
        // this routine initialises the import object
        $re = $this->defaultreferentiel();
        // 
		// $re->id = $this->getpath( $xmlreferentiel, array('#','id',0,'#'), '', false, '');
        $re->name = $this->getpath( $xmlreferentiel, array('#','name','0','#'), '', true, $error_noname);
        $re->code_referentiel = $this->getpath( $xmlreferentiel, array('#','code_referentiel',0,'#'), '', true, $error_nocode);
        $re->description_referentiel = $this->getpath( $xmlreferentiel, array('#','description_referentiel',0,'#','text',0,'#'), '', true, '');
        $re->url_referentiel = $this->getpath( $xmlreferentiel, array('#','url_referentiel',0,'#'), '', true, '');		
		$re->seuil_certificat = $this->getpath( $xmlreferentiel, array('#','seuil_certificat',0,'#'), '', false, '');
		$re->timemodified = $this->getpath( $xmlreferentiel, array('#','timemodified',0,'#'), '', false, '');		
		$re->nb_domaines = $this->getpath( $xmlreferentiel, array('#','nb_domaines',0,'#'), '', false, '');				
		$re->liste_codes_competence = $this->getpath( $xmlreferentiel, array('#','liste_codes_competence',0,'#'), '', true, '');
		$re->liste_empreintes_competence = $this->getpath( $xmlreferentiel, array('#','liste_empreintes_competence',0,'#'), '', true, '');
		$re->logo_referentiel = $this->getpath( $xmlreferentiel, array('#','logo_referentiel',0,'#'), '', true, '');
		// $re->local = $this->getpath( $xmlreferentiel, array('#','course',0,'#'), '', false, '');				
		
		/*
		// traitement d'une image associee
		// non implante
        $image = $this->getpath( $xmlreferentiel, array('#','image',0,'#'), $re->image );
        $image_base64 = $this->getpath( $xmlreferentiel, array('#','image_base64','0','#'),'' );
        if (!empty($image_base64)) {
            $re->image = $this->importimagefile( $image, stripslashes($image_base64) );
        }
		*/
		
		$re->export_process = false;
		$re->import_process = true;
		
		// le referentiel est toujours place dans le cours local d'appel 
		$re->course = $this->course->id;
		
		$risque_ecrasement=false;
		if (!isset($this->action) || ($this->action!="importreferentiel")){
			// importer dans le cours courant en remplacement du referentiel courant
			// Verifier si ecrasement referentiel local
			
			if (isset($re->name) && ($re->name!="")
				&& 
				isset($re->code_referentiel) && ($re->code_referentiel!="")
				&& 
				isset($re->id) && ($re->id>0)
				&& 
				isset($re->course) && ($re->course>0)){
				// sauvegarder ?
				if ($this->course->id==$re->course){
					if (	
						(isset($this->rreferentiel->id) && ($this->rreferentiel->id==$re->id))
						|| 
						(
							(isset($this->rreferentiel->name) && ($this->rreferentiel->name==$re->name)) 
							&& 
							(isset($this->rreferentiel->code_referentiel) && ($this->rreferentiel->code_referentiel==$re->code_referentiel))
						)
					)
					{
						$risque_ecrasement=true;
					}
				}
			}
		}
		
		if (($risque_ecrasement==false) || ($this->newinstance==1)) {
			// Enregistrer dans la base comme un nouveau referentiel du cours courant
			$new_referentiel_id=referentiel_add_referentiel($re);
			$this->setReferentielId($new_referentiel_id);
			// DEBUG
			// echo "<br />DEBUG xml/format.php ligne 572<br />NEW REFERENTIEL ID ENREGISTRE : ".$this->new_referentiel_id."\n";			
		}
		else if (($risque_ecrasement==true) && ($this->override==1)) {
			// Enregistrer dans la base en rempla�ant la version courante (update)
			// NE FAUDRAIT IL PAS SUPPRIMER LE REFERENTIEL AVANT DE LA RECHARGER ?
			$re->instance=$this->rreferentiel->id;
			$re->referentiel_id=$this->rreferentiel->id;
			$ok=referentiel_update_referentiel($re);
			$new_referentiel_id=$this->rreferentiel->id;
		}
		else {
			// ni nouvelle instance ni recouvrement
			$this->error( $error_override );
			return false;
		}
		
		// importer les domaines
		$xmldomaines = $xmlreferentiel['#']['domaine'];
		$dindex=0;
        $re->domaines = array();
		
        foreach ($xmldomaines as $domaine) {
			// DOMAINES
			// print_r($domaine);
			$dindex++;
			$new_domaine = array();
			$new_domaine = $this->defaultdomaine();
			// $new_domaine->id=$this->getpath( $domaine, array('#','id',0,'#'), '', false, '');	
			$new_domaine->code_domaine=$this->getpath( $domaine, array('#','code_domaine',0,'#'), '', true, $error_nocode);
			$new_domaine->description_domaine=$this->getpath( $domaine, array('#','description_domaine',0,'#','text',0,'#'), '', true, '');
			$new_domaine->num_domaine=$this->getpath( $domaine, array('#','num_domaine',0,'#'), '', false, '');
			$new_domaine->nb_competences=$this->getpath( $domaine, array('#','nb_competences',0,'#'), '', false, '');
			// $new_domaine->ref_referentiel=$this->getpath( $domaine, array('#','ref_referentiel',0,'#'), '', false, '');
			
			// enregistrer
			$re->domaines[$dindex]=$new_domaine;
			
			// sauvegarder dans la base
			// remplacer l'id du referentiel importe par l'id du referentiel cree
			// trafiquer les donnees pour appeler la fonction ad hoc
			$new_domaine->ref_referentiel=$new_referentiel_id;
			$new_domaine->instance=$new_referentiel_id; // pour que ca marche
			$new_domaine->new_code_domaine=$new_domaine->code_domaine;
			$new_domaine->new_description_domaine=$new_domaine->description_domaine;
			$new_domaine->new_num_domaine=$new_domaine->num_domaine;
			$new_domaine->new_nb_competences=$new_domaine->num_domaine;
			$new_domaine_id=referentiel_add_domaine($new_domaine);
			
			// importer les competences
			$xmlcompetences = $domaine['#']['competence'];
			
			$cindex=0;
			$re->domaines[$dindex]->competences=array();
			
	        foreach ($xmlcompetences as $competence) {
				$cindex++;
				$new_competence = array();
				$new_competence = $this->defaultcompetence();
		    	// $new_competence->id = $this->getpath( $competence, array('#','id',0,'#'), '', false, '');
				$new_competence->code_competence=$this->getpath( $competence, array('#','code_competence',0,'#'), '', true, $error_nocode);
				$new_competence->description_competence=$this->getpath( $competence, array('#','description_competence',0,'#','text',0,'#'), '', true, '');
				$new_competence->num_competence=$this->getpath( $competence, array('#','num_competence',0,'#'), '', false, '');
				$new_competence->nb_item_competences=$this->getpath( $competence, array('#','nb_item_competences',0,'#'), '', false, '');
				// $new_competence->ref_domaine=$this->getpath( $competence, array('#','ref_domaine',0,'#'), '', false, '');
				
				// enregistrer
				$re->domaines[$dindex]->competences[$cindex]=$new_competence;
				
				// sauvegarder dans la base
					// remplacer l'id du referentiel importe par l'id du referentiel cree
					$new_competence->ref_domaine=$new_domaine_id;
					// trafiquer les donnees pour appeler la fonction ad hoc
					$new_competence->instance=$new_referentiel_id; // pour que ca marche
					$new_competence->new_code_competence=$new_competence->code_competence;
					$new_competence->new_description_competence=$new_competence->description_competence;
					$new_competence->new_ref_domaine=$new_competence->ref_domaine;
					$new_competence->new_num_competence=$new_competence->num_competence;
					$new_competence->new_nb_item_competences=$new_competence->nb_item_competences;
					// creation
					$new_competence_id=referentiel_add_competence($new_competence);
				
				// importer les items
				$xmlitems = $competence['#']['item'];
				$iindex=0;
				$re->domaines[$dindex]->competences[$cindex]->items=array();
				
		        foreach ($xmlitems as $item) {
					$iindex++;
					$new_item = array();
					$new_item = $this->defaultitem();
					// $new_item->id = $this->getpath( $item, array('#','id',0,'#'), '', false, '');
					$new_item->code_item = $this->getpath( $item, array('#','code',0,'#'), '', true, $error_nocode);
					$new_item->description_item=$this->getpath( $item, array('#','description_item',0,'#','text',0,'#'), '', true, '');
					$new_item->num_item=$this->getpath( $item, array('#','num_item',0,'#'), '', false, '');
					$new_item->type_item=$this->getpath( $item, array('#','type_item',0,'#'), '', true, '');
					$new_item->poids_item=$this->getpath( $item, array('#','poids_item',0,'#'), '', false, '');
					// $new_item->ref_competence=$this->getpath( $item, array('#','ref_competence',0,'#'), '', false, '');
					// $new_item->ref_referentiel=$this->getpath( $item, array('#','ref_referentiel',0,'#'), '', false, '');
					$new_item->empreinte_item=$this->getpath( $item, array('#','empreinte_item',0,'#'), '', false, '');					
					// enregistrer
					$re->domaines[$dindex]->competences[$cindex]->items[$iindex]=$new_item; 
					
					// sauvegarder dans la base

						// remplacer l'id du referentiel importe par l'id du referentiel cree
						$new_item->ref_referentiel=$new_referentiel_id;
						$new_item->ref_competence=$new_competence_id;
						// trafiquer les donnees pour pouvoir appeler la fonction ad hoc
						$new_item->instance=$new_item->ref_referentiel;
						$new_item->new_ref_competence=$new_item->ref_competence;
						$new_item->new_code_item=$new_item->code_item;
						$new_item->new_description_item=$new_item->description_item;
						$new_item->new_num_item=$new_item->num_item;
						$new_item->new_type_item=$new_item->type_item;
						$new_item->new_poids_item=$new_item->poids_item;
						$new_item->new_empreinte_item=$new_item->empreinte_item;
						// creer
						$new_item_id=referentiel_add_item($new_item);
					// that's all folks
				}
			}
        }
        return $re;
    }



    /**
     * parse the array of lines into an array of questions
     * this *could* burn memory - but it won't happen that much
     * so fingers crossed!
     * @param array lines array of lines from the input file
     * @return array (of objects) question objects
     */
    function read_import_referentiel($lines) {
        // we just need it as one big string
        $text = implode($lines, " ");
        unset( $lines );

        // this converts xml to big nasty data structure
        // the 0 means keep white space as it is (important for markdown format)
        // print_r it if you want to see what it looks like!
        $xml = xmlize( $text, 0 ); 
		
		// DEBUG
		// echo "<br />DEBUG xml/format.php :: ligne 580<br />\n";
		// print_r($xml);
		// echo "<br /><br />\n";		
		// print_r($xml['referentiel']['domaine']['competence']);
		// print_r($xml['referentiel']['#']['domaine']['#']);
		// echo "<br /><br />\n";		
		// exit;
		$re=$this->import_referentiel($xml['referentiel']);
        // stick the result in the $treferentiel array
 		// DEBUG
		// echo "<br />DEBUG xml/format.php :: ligne 632\n";
		// print_r($re);
        return $re;
    }
}
 
 
/**********************************************************************
***********************************************************************
									ACTIVITES
***********************************************************************
**********************************************************************/

class aformat_xml extends aformat_default {

    function provide_import() {
        return false;
    }

    function provide_export() {
        return true;
    }


    // EXPORT FUNCTIONS START HERE

    function export_file_extension() {
    // override default type so extension is .xml
        return ".xml";
    }


    /**
     * Convert internal Moodle text format code into
     * human readable form
     * @param int id internal code
     * @return string format text
     */
    function get_format( $id ) {
        switch( $id ) {
        case 0:
            $name = "moodle_auto_format";
            break;
        case 1:
            $name = "html";
            break;
        case 2:
            $name = "plain_text";
            break;
        case 3:
            $name = "wiki_like";
            break;
        case 4:
            $name = "markdown";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * Convert internal single question code into 
     * human readable form
     * @param int id single question code
     * @return string single question string
     */
    function get_single( $id ) {
        switch( $id ) {
        case 0:
            $name = "false";
            break;
        case 1:
            $name = "true";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function writetext( $raw, $ilev=0, $short=true) {
        $indent = str_repeat( "  ",$ilev );

        // encode the text to 'disguise' HTML content 
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
		
        $raw = htmlspecialchars( $raw );

        if ($short) {
            $xml = "$indent<text>$raw</text>\n";
        }
        else {
            $xml = "$indent<text>\n$raw\n$indent</text>\n";
        }

        return $xml;
    }

    /**
     * generates raw text therein 
     * @return string not formatted text
     */

    function writeraw( $raw) {
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
	    return $raw;
    }
  
    function xmltidy( $content ) {
        // can only do this if tidy is installed
        if (extension_loaded('tidy')) {
            $config = array( 'input-xml'=>true, 'output-xml'=>true, 'indent'=>true, 'wrap'=>0 );
            $tidy = new tidy;
            $tidy->parseString($content, $config, 'utf8');
            $tidy->cleanRepair(); 
            return $tidy->value;
        }
        else {
            return $content;
        }
    }


    function presave_process( $content ) {
    // override method to allow us to add xml headers and footers

        // add the xml headers and footers
        $content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
                       "<certification>\n" .
                       $content . "\n" .
                       "</certification>";

        // make the xml look nice
        $content = $this->xmltidy( $content );

        return $content;
    }

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	 /**
     * Turns document into an xml segment
     * @param document object
     * @return string xml segment
     */

    function write_document( $document ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- document: $document->id  -->\n";
		//
		if ($document){
			$id = $this->writeraw( $document->id );		
            $type_document = $this->writeraw( trim($document->type_document));
            $description_document = $this->writetext(trim($document->description_document));
			$url_document = $this->writeraw( $document->url_document);
            $ref_activite = $this->writeraw( $document->ref_activite);

            $expout .= "<document>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<type_document>$type_document</type_document>\n";   
            $expout .= "<description_document>\n$description_document</description_document>\n";
            $expout .= "<url_document>$url_document</url_document>\n";
            $expout .= "<ref_activite>$ref_activite</ref_activite>\n";
			$expout .= "</document>\n";   
        }
        return $expout;
    }

    /**
     * Turns activite into an xml segment
     * @param activite object
     * @return string xml segment
     */

    function write_activite( $activite ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- activite: $activite->id  -->\n";
		// 
		if ($activite){
			// DEBUG
			// echo "<br />DEBUG LIGNE 960<br />\n";
			// print_r($activite);
			
			$id = $this->writeraw( $activite->id );
            $type_activite = $this->writeraw( trim($activite->type_activite));
            $description_activite = $this->writetext(trim($activite->description_activite));
            $competences_activite = $this->writeraw(trim($activite->competences_activite));
            $commentaire_activite = $this->writetext(trim($activite->commentaire_activite));
            $ref_instance = $this->writeraw( $activite->ref_instance);
            $ref_referentiel = $this->writeraw( $activite->ref_referentiel);
            $ref_course = $this->writeraw( $activite->ref_course);
			$userid = $this->writeraw( trim($activite->userid));
			$teacherid = $this->writeraw( $activite->teacherid);
			$date_creation = $this->writeraw( $activite->date_creation);
			$date_modif = $this->writeraw( $activite->date_modif);
			$approved = $this->writeraw( $activite->approved);
			
            $expout .= "<activite>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<type_activite>$type_activite</type_activite>\n";
            $expout .= "<description_activite>\n$description_activite</description_activite>\n";
            $expout .= "<competences_activite>$competences_activite</competences_activite>\n";
            $expout .= "<commentaire_activite>\n$commentaire_activite</commentaire_activite>\n";
            $expout .= "<ref_instance>$ref_instance</ref_instance>\n";
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "<ref_course>$ref_course</ref_course>\n";
            $expout .= "<userid>$userid</userid>\n";
            $expout .= "<teacherid>$teacherid</teacherid>\n";
            $expout .= "<date_creation>$date_creation</date_creation>\n";
            $expout .= "<date_modif>$date_modif</date_modif>\n";
            $expout .= "<approved>$approved</approved>\n";

			// DOCUMENTS
			$records_documents = referentiel_get_documents($activite->id);
			
			if ($records_documents){
				foreach ($records_documents as $record_d){
					$expout .= $this->write_document( $record_d );
				}
			}
			
			$expout .= "</activite>\n";
        }
        return $expout;
    }

	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- instance : $referentiel_instance->id  -->\n";
		// 
		if ($referentiel_instance){
			// DEBUG
			// echo "<br />DEBUG LIGNE 1021<br />\n";
			// print_r($referentiel_instance);
			
			$id = $this->writeraw( $referentiel_instance->id );
            $name = $this->writeraw( trim($referentiel_instance->name) );
            $description_instance = $this->writetext(trim($referentiel_instance->description_instance));
            $label_domaine = $this->writeraw( trim($referentiel_instance->label_domaine) );
            $label_competence = $this->writeraw( trim($referentiel_instance->label_competence) );
            $label_item = $this->writeraw( trim($referentiel_instance->label_item) );
            $date_instance = $this->writeraw( $referentiel_instance->date_instance);
            $course = $this->writeraw( $referentiel_instance->course);
            $ref_referentiel = $this->writeraw( $referentiel_instance->ref_referentiel);
			$visible = $this->writeraw( $referentiel_instance->visible );
			
			$expout .= "<id>$id</id>\n";
			$expout .= "<name>$name</name>\n";   
            $expout .= "<description_instance>\n$description_instance</description_instance>\n";
            $expout .= "<label_domaine>$label_domaine</label_domaine>\n";
            $expout .= "<label_competence>$label_competence</label_competence>\n";
            $expout .= "<label_item>$label_item</label_item>\n";
            $expout .= "<date_instance>$date_instance</date_instance>\n";
            $expout .= "<course>$course</course>\n";
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "<visible>$visible</visible>\n";
			
			// ACTIVITES
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				$records_activites = referentiel_get_activites($referentiel_instance->ref_referentiel);
				// print_r($records_activites);
				
		    	if ($records_activites){
					foreach ($records_activites as $record_a){
						$expout .= $this->write_activite( $record_a );
					}
				}
			}
        }
        return $expout;
    }
}


class cformat_xml extends cformat_default {

    function provide_import() {
        return false;
    }

    function provide_export() {
        return true;
    }


    // EXPORT FUNCTIONS START HERE

    function export_file_extension() {
    // override default type so extension is .xml
        return ".xml";
    }


    /**
     * Convert internal Moodle text format code into
     * human readable form
     * @param int id internal code
     * @return string format text
     */
    function get_format( $id ) {
        switch( $id ) {
        case 0:
            $name = "moodle_auto_format";
            break;
        case 1:
            $name = "html";
            break;
        case 2:
            $name = "plain_text";
            break;
        case 3:
            $name = "wiki_like";
            break;
        case 4:
            $name = "markdown";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * Convert internal single question code into 
     * human readable form
     * @param int id single question code
     * @return string single question string
     */
    function get_single( $id ) {
        switch( $id ) {
        case 0:
            $name = "false";
            break;
        case 1:
            $name = "true";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function writetext( $raw, $ilev=0, $short=true) {
        $indent = str_repeat( "  ",$ilev );

        // encode the text to 'disguise' HTML content 
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
		
        $raw = htmlspecialchars( $raw );

        if ($short) {
            $xml = "$indent<text>$raw</text>\n";
        }
        else {
            $xml = "$indent<text>\n$raw\n$indent</text>\n";
        }

        return $xml;
    }

    /**
     * generates raw text therein 
     * @return string not formatted text
     */

    function writeraw( $raw) {
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
	    return $raw;
    }
  
    function xmltidy( $content ) {
        // can only do this if tidy is installed
        if (extension_loaded('tidy')) {
            $config = array( 'input-xml'=>true, 'output-xml'=>true, 'indent'=>true, 'wrap'=>0 );
            $tidy = new tidy;
            $tidy->parseString($content, $config, 'utf8');
            $tidy->cleanRepair(); 
            return $tidy->value;
        }
        else {
            return $content;
        }
    }


    function presave_process( $content ) {
    // override method to allow us to add xml headers and footers

        // add the xml headers and footers
        $content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
                       "<certification>\n" .
                       $content . "\n" .
                       "</certification>";

        // make the xml look nice
        $content = $this->xmltidy( $content );

        return $content;
    }

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

		function write_etablissement( $record ) {
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- etablissement: $record->id  -->\n";
		if ($record){
			// DEBUG
			// echo "<br />\n";
			// print_r($record);
			$id = $this->writeraw( $record->id );
			$num_etablissement = $this->writeraw( $record->num_etablissement);
			$nom_etablissement = $this->writeraw( $record->nom_etablissement);
			$adresse_etablissement = $this->writetext( $record->adresse_etablissement);
			$logo = $this->writeraw( $record->logo_etablissement);
						
            $expout .= "<etablissement>\n";
			$expout .= "<id>$id</id>\n";
            $expout .= "<num_etablissement>$num_etablissement</$num_etablissement>\n";
            $expout .= "<nom_etablissement>$nom_etablissement</nom_etablissement>\n";			
            $expout .= "<adresse_etablissement>\n$adresse_etablissement</adresse_etablissement>\n";
            $expout .= "<logo_etablissement>$logo</logo_etablissement>\n";			
			$expout .= "</etablissement>\n\n";
        }
        return $expout;
    }


	
	function write_etudiant( $record ) {
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- etudiant: $record->id  -->\n";
		if ($record){
			// DEBUG
			// echo "<br />\n";
			// print_r($record);
			$id = $this->writeraw( $record->id );
			$userid = $this->writeraw( $record->userid );
            $ref_etablissement = $this->writeraw( $record->ref_etablissement);
			$num_etudiant = $this->writeraw( $record->num_etudiant);
			$ddn_etudiant = $this->writeraw( $record->ddn_etudiant);
			$lieu_naissance = $this->writeraw( $record->lieu_naissance);
			$departement_naissance = $this->writeraw( $record->departement_naissance);
			$adresse_etudiant = $this->writeraw( $record->adresse_etudiant);
            $expout .= "<etudiant>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<userid>$userid</userid>\n";
			$expout .= "<lastname_firstname>".referentiel_get_user_info($record->userid)."</lastname_firstname>\n";
			$expout .= "<num_etudiant>$num_etudiant</num_etudiant>\n";
            $expout .= "<ddn_etudiant>$ddn_etudiant</ddn_etudiant>\n";
            $expout .= "<lieu_naissance>$lieu_naissance</lieu_naissance>\n";
            $expout .= "<departement_naissance>$departement_naissance</departement_naissance>\n";			
            $expout .= "<adresse_etudiant>$adresse_etudiant</adresse_etudiant>\n";
			$expout .= "<ref_etablissement>$ref_etablissement</ref_etablissement>\n";
			// Etablissement
			$record_etablissement=referentiel_get_etablissement($record->ref_etablissement);
	    	if ($record_etablissement){
				$expout .= $this->write_etablissement( $record_etablissement );
			}
			$expout .= "</etudiant>\n\n";
        }
        return $expout;
    }

	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certificat( $record ) {
    	global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- certificat : $record->id  -->\n";
		// 
		if ($record){
			// DEBUG
			// echo "<br />DEBUG LIGNE 1298<br />\n";
			// print_r($record);
			
			$id = $this->writeraw( $record->id );
            $commentaire_certificat = $this->writetext(trim($record->commentaire_certificat));
            $competences_certificat = $this->writeraw( trim($record->competences_certificat) );
            $decision_jury = $this->writeraw( trim($record->decision_jury) );
            $date_decision = $this->writeraw( userdate(trim($record->date_decision)) );
            $userid = $this->writeraw( $record->userid);
            $teacherid = $this->writeraw( $record->teacherid);
            $ref_referentiel = $this->writeraw( $record->ref_referentiel);
			$verrou = $this->writeraw( $record->verrou );
			$valide = $this->writeraw( $record->valide );
			$evaluation = $this->writeraw( $record->evaluation );			
			
			$expout .= "<certificat>\n";
			$expout .= "<id>$id</id>\n";
		// DEBUG
		// echo "<br />DEBUG LIGNE 1314<br />\n";
		// echo htmlentities ($expout, ENT_QUOTES, 'UTF-8')  ;
		
			
			// USER
			if (isset($record->userid) && ($record->userid>0)){
				$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    	if ($record_etudiant){
					$expout .= $this->write_etudiant( $record_etudiant );
				}
			}
		// DEBUG
		// echo "<br />DEBUG LIGNE 1326<br />\n";
		// echo htmlentities ($expout, ENT_QUOTES, 'UTF-8')  ;
            $expout .= "<commentaire_certificat>\n$commentaire_certificat</commentaire_certificat>\n";			
            $expout .= "<competences_certificat>$competences_certificat</competences_certificat>\n";
            $expout .= "<decision_jury>$decision_jury</decision_jury>\n";
            $expout .= "<date_decision>$date_decision</date_decision>\n";			
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "<verrou>$verrou</verrou>\n";
            $expout .= "<valide>$valide</valide>\n";
			$expout .= "<evaluation>$evaluation</evaluation>\n";			
			$expout .= "</certificat>\n\n";
        }
		// DEBUG
		// echo "<br />DEBUG LIGNE 1330<br />\n";
		// echo htmlentities ($expout, ENT_QUOTES, 'UTF-8')  ;
		
        return $expout;
    }
    /**
     * Turns item into an xml segment
     * @param item object
     * @return string xml segment
     */

    function write_item( $item ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- item: $item->id  -->\n";
		// 
		if ($item){
			// DEBUG
			// echo "<br />\n";
			// print_r($item);
			$id = $this->writeraw( $item->id );
            $code = $this->writeraw( trim($item->code_item));
            $description_item = $this->writetext(trim($item->description_item));
            $ref_referentiel = $this->writeraw( $item->ref_referentiel);
            $ref_competence = $this->writeraw( $item->ref_competence);
			$type_item = $this->writeraw( trim($item->type_item));
			$poids_item = $this->writeraw( $item->poids_item);
			$num_item = $this->writeraw( $item->num_item);
            $expout .= "<item>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<code>$code</code>\n";
            $expout .= "<description_item>\n$description_item</description_item>\n";
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "<ref_competence>$ref_competence</ref_competence>\n";
            $expout .= "<type_item>$type_item</type_item>\n";
            $expout .= "<poids_item>$poids_item</poids_item>\n";
            $expout .= "<num_item>$num_item</num_item>\n";
			$expout .= "</item>\n";
        }
        return $expout;
    }

	 /**
     * Turns competence into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_competence( $competence ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- competence: $competence->id  -->\n";
		//
		if ($competence){
			$id = $this->writeraw( $competence->id );		
            $code = $this->writeraw( trim($competence->code_competence));
            $description_competence = $this->writetext(trim($competence->description_competence));
            $ref_domaine = $this->writeraw( $competence->ref_domaine);
			$num_competence = $this->writeraw( $competence->num_competence);
			$nb_item_competences = $this->writeraw( $competence->nb_item_competences);
            $expout .= "<competence>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<code_competence>$code</code_competence>\n";   
            $expout .= "<description_competence>\n$description_competence</description_competence>\n";
            $expout .= "<ref_domaine>$ref_domaine</ref_domaine>\n";
            $expout .= "<num_competence>$num_competence</num_competence>\n";
            $expout .= "<nb_item_competences>$nb_item_competences</nb_item_competences>\n";
							
			// ITEM
			$compteur_item=0;
			$records_items = referentiel_get_item_competences($competence->id);
			
			if ($records_items){
				// DEBUG
				// echo "<br/>DEBUG :: ITEMS <br />\n";
				// print_r($records_items);
				foreach ($records_items as $record_i){
					// DEBUG
					// echo "<br/>DEBUG :: ITEM <br />\n";
					// print_r($record_i);
					$expout .= $this->write_item( $record_i );
				}
			}
			$expout .= "</competence>\n";   
        }
        return $expout;
    }


	 /**
     * Turns domaine into an xml segment
     * @param domaine object
     * @return string xml segment
     */

    function write_domaine( $domaine ) {
    global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- domaine: $domaine->id  -->\n";
		// 
		if ($domaine){
			$id = $this->writeraw( $domaine->id );
            $code = $this->writeraw( trim($domaine->code_domaine) );
            $description_domaine = $this->writetext(trim($domaine->description_domaine));
            $ref_referentiel = $this->writeraw( $domaine->ref_referentiel );
			$num_domaine = $this->writeraw( $domaine->num_domaine );
			$nb_competences = $this->writeraw( $domaine->nb_competences );
            $expout .= "<domaine>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<code_domaine>$code</code_domaine>\n";   
            $expout .= "<description_domaine>\n$description_domaine</description_domaine>\n";
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
            $expout .= "<num_domaine>$num_domaine</num_domaine>\n";
            $expout .= "<nb_competences>$nb_competences</nb_competences>\n";
			
			// LISTE DES COMPETENCES DE CE DOMAINE
			$compteur_competence=0;
			$records_competences = referentiel_get_competences($domaine->id);
			if ($records_competences){
				// DEBUG
				// echo "<br/>DEBUG :: COMPETENCES <br />\n";
				// print_r($records_competences);
				foreach ($records_competences as $record_c){
					$expout .= $this->write_competence( $record_c );
				}
			}
			$expout .= " </domaine>\n";   
        }
        return $expout;
    }



	 /**
     * Turns referentiel into an xml segment
     * @param competence object
     * @return string xml segment
     */

    function write_referentiel( $referentiel ) {
    	global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- referentiel: $referentiel->id  -->\n";
		// 
		if ($referentiel){
			$id = $this->writeraw( $referentiel->id );
            $name = $this->writeraw( trim($referentiel->name) );
            $code_referentiel = $this->writeraw( trim($referentiel->code_referentiel));
            $description_referentiel = $this->writetext(trim($referentiel->description_referentiel));
            $url_referentiel = $this->writeraw( trim($referentiel->url_referentiel) );
			$seuil_certificat = $this->writeraw( $referentiel->seuil_certificat );
			$timemodified = $this->writeraw( $referentiel->timemodified );			
			$nb_domaines = $this->writeraw( $referentiel->nb_domaines );
			$liste_codes_competence = $this->writeraw( trim($referentiel->liste_codes_competence) );
			$local = $this->writeraw( $referentiel->local );
			$expout .= "<id>$id</id>\n";
			$expout .= "<name>$name</name>\n";   
			$expout .= "<code_referentiel>$code_referentiel</code_referentiel>\n";   
            $expout .= "<description_referentiel>\n$description_referentiel</description_referentiel>\n";
            $expout .= "<url_referentiel>$url_referentiel</url_referentiel>\n";
            $expout .= "<seuil_certificat>$seuil_certificat</seuil_certificat>\n";
            $expout .= "<timemodified>$timemodified</timemodified>\n";			
            $expout .= "<nb_domaines>$nb_domaines</nb_domaines>\n";
            $expout .= "<liste_codes_competence>$liste_codes_competence</liste_codes_competence>\n";
			$expout .= "<local>$local</local>\n";
			
			// DOMAINES
			if (isset($referentiel->id) && ($referentiel->id>0)){
				// LISTE DES DOMAINES
				$compteur_domaine=0;
				$records_domaine = referentiel_get_domaines($referentiel->id);
		    	if ($records_domaine){
    				// afficher
					// DEBUG
					// echo "<br/>DEBUG ::<br />\n";
					// print_r($records_domaine);
					foreach ($records_domaine as $record_d){
						// DEBUG
						// echo "<br/>DEBUG ::<br />\n";
						// print_r($records_domaine);
						$expout .= $this->write_domaine( $record_d );
					}
				}
			}
        }
        return $expout;
    }


	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_certification( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
        // add comment		
        $expout .= "\n\n<!-- instance : $referentiel_instance->id  -->\n";
		// 

		if ($referentiel_instance){
			// DEBUG
			// echo "<br />DEBUG LIGNE 1348<br />\n";
			// print_r($referentiel_instance);
			
			$id = $this->writeraw( $referentiel_instance->id );
            $name = $this->writeraw( trim($referentiel_instance->name) );
            $description_instance = $this->writetext(trim($referentiel_instance->description_instance));
            $label_domaine = $this->writeraw( trim($referentiel_instance->label_domaine) );
            $label_competence = $this->writeraw( trim($referentiel_instance->label_competence) );
            $label_item = $this->writeraw( trim($referentiel_instance->label_item) );
            $date_instance = $this->writeraw( userdate($referentiel_instance->date_instance));
            $course = $this->writeraw( $referentiel_instance->course);
            $ref_referentiel = $this->writeraw( $referentiel_instance->ref_referentiel);
			$visible = $this->writeraw( $referentiel_instance->visible );

			$expout .= "<instance>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<name>$name</name>\n";   
            $expout .= "<description_instance>\n$description_instance</description_instance>\n";
            $expout .= "<label_domaine>$label_domaine</label_domaine>\n";
            $expout .= "<label_competence>$label_competence</label_competence>\n";
            $expout .= "<label_item>$label_item</label_item>\n";
            $expout .= "<date_instance>$date_instance</date_instance>\n";
            $expout .= "<course>$course</course>\n";			
            $expout .= "<visible>$visible</visible>\n";
			// referentiel
            $expout .= "<ref_referentiel>$ref_referentiel</ref_referentiel>\n";
			
			
			// CERTIFICATS
			if (isset($referentiel_instance->ref_referentiel) && ($referentiel_instance->ref_referentiel>0)){
				
				$record_referentiel = referentiel_get_referentiel_referentiel($referentiel_instance->ref_referentiel);
				$expout .= $this->write_referentiel($record_referentiel);
				
				$records_certificats = referentiel_get_certificats($referentiel_instance->ref_referentiel);
				// echo "<br />DEBUG LIGNE 1377<br />\n";
				// print_r($records_certificats);
				// exit;
		    	if ($records_certificats){
					foreach ($records_certificats as $record){
						$expout .= $this->write_certificat( $record );
					}
				}
			}
			$expout .= "</instance>\n\n";
        }
        return $expout;
    }
}


// ****************************************************************
// ETUDIANT

class eformat_xml extends eformat_default {

    function provide_import() {
        return false;
    }

    function provide_export() {
        return true;
    }


    // EXPORT FUNCTIONS START HERE

    function export_file_extension() {
    // override default type so extension is .xml
        return ".xml";
    }


    /**
     * Convert internal Moodle text format code into
     * human readable form
     * @param int id internal code
     * @return string format text
     */
    function get_format( $id ) {
        switch( $id ) {
        case 0:
            $name = "moodle_auto_format";
            break;
        case 1:
            $name = "html";
            break;
        case 2:
            $name = "plain_text";
            break;
        case 3:
            $name = "wiki_like";
            break;
        case 4:
            $name = "markdown";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * Convert internal single question code into 
     * human readable form
     * @param int id single question code
     * @return string single question string
     */
    function get_single( $id ) {
        switch( $id ) {
        case 0:
            $name = "false";
            break;
        case 1:
            $name = "true";
            break;
        default:
            $name = "unknown";
        }
        return $name;
    }

    /**
     * generates <text></text> tags, processing raw text therein 
     * @param int ilev the current indent level
     * @param boolean short stick it on one line
     * @return string formatted text
     */

    function writetext( $raw, $ilev=0, $short=true) {
        $indent = str_repeat( "  ",$ilev );

        // encode the text to 'disguise' HTML content 
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
		
        $raw = htmlspecialchars( $raw );

        if ($short) {
            $xml = "$indent<text>$raw</text>\n";
        }
        else {
            $xml = "$indent<text>\n$raw\n$indent</text>\n";
        }

        return $xml;
    }

    /**
     * generates raw text therein 
     * @return string not formatted text
     */

    function writeraw( $raw) {
		$raw=ereg_replace("\r", "", $raw);
		$raw=ereg_replace("\n", "", $raw);
	    return $raw;
    }
  
    function xmltidy( $content ) {
        // can only do this if tidy is installed
        if (extension_loaded('tidy')) {
            $config = array( 'input-xml'=>true, 'output-xml'=>true, 'indent'=>true, 'wrap'=>0 );
            $tidy = new tidy;
            $tidy->parseString($content, $config, 'utf8');
            $tidy->cleanRepair(); 
            return $tidy->value;
        }
        else {
            return $content;
        }
    }


    function presave_process( $content ) {
    // override method to allow us to add xml headers and footers

        // add the xml headers and footers
        $content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
                       "<etudiants>\n" .
                       $content . "\n" .
                       "</etudiants>";

        // make the xml look nice
        $content = $this->xmltidy( $content );

        return $content;
    }

    /**
     * Include an image encoded in base 64
     * @param string imagepath The location of the image file
     * @return string xml code segment 
     */
    function writeimage( $imagepath ) {
        global $CFG;
   		
        if (empty($imagepath)) {
            return '';
        }

        $courseid = $this->course->id;
        if (!$binary = file_get_contents( "{$CFG->dataroot}/$courseid/$imagepath" )) {
            return '';
        }

        $content = "    <image_base64>\n".addslashes(base64_encode( $binary ))."\n".
            "\n    </image_base64>\n";
        return $content;
    }

	function write_etablissement( $record ) {
        // initial string;
        $expout = "";
		if ($record){
			$id = $this->writeraw( $record->id );
			$num_etablissement = $this->writeraw( $record->num_etablissement);
			$nom_etablissement = $this->writeraw( $record->nom_etablissement);
			$adresse_etablissement = $this->writetext( $record->adresse_etablissement);
			// $logo = $this->writeraw( $record->logo_etablissement);
            $expout .= "<etablissement>\n";
			$expout .= "<id>$id</id>\n";
            $expout .= "<num_etablissement>$num_etablissement</$num_etablissement>\n";
            $expout .= "<nom_etablissement>$nom_etablissement</nom_etablissement>\n";			
            $expout .= "<adresse_etablissement>\n$adresse_etablissement</adresse_etablissement>\n";
            // $expout .= "<logo_etablissement>$logo</logo_etablissement>\n";			
			$expout .= "</etablissement>\n";
        }
        return $expout;
    }
	
	function write_etudiant( $record ) {
        // initial string;
        $expout = "";
        // add comment
        $expout .= "\n\n<!-- etudiant: $record->id  -->\n";
		if ($record){
			// DEBUG
			// echo "<br />\n";
			// print_r($record);
			$id = $this->writeraw( $record->id );
			$userid = $this->writeraw( $record->userid );
            $ref_etablissement = $this->writeraw( $record->ref_etablissement);
			$num_etudiant = $this->writeraw( $record->num_etudiant);
			$ddn_etudiant = $this->writeraw( $record->ddn_etudiant);
			$lieu_naissance = $this->writeraw( $record->lieu_naissance);
			$departement_naissance = $this->writeraw( $record->departement_naissance);
			$adresse_etudiant = $this->writeraw( $record->adresse_etudiant);
            $expout .= "<etudiant>\n";
			$expout .= "<id>$id</id>\n";
			$expout .= "<userid>$userid</userid>\n";
			$expout .= "<lastname_firstname>".referentiel_get_user_info($record->userid)."</lastname_firstname>\n";
			$expout .= "<num_etudiant>$num_etudiant</num_etudiant>\n";
            $expout .= "<ddn_etudiant>$ddn_etudiant</ddn_etudiant>\n";
            $expout .= "<lieu_naissance>$lieu_naissance</lieu_naissance>\n";
            $expout .= "<departement_naissance>$departement_naissance</departement_naissance>\n";			
            $expout .= "<adresse_etudiant>$adresse_etudiant</adresse_etudiant>\n";
			$expout .= "<ref_etablissement>$ref_etablissement</ref_etablissement>\n";
			
	/*
			// Etablissement
			$record_etablissement=referentiel_get_etablissement($record->ref_etablissement);
	    	if ($record_etablissement){
				$expout .= $this->write_etablissement( $record_etablissement );
			}
	*/
			$expout .= "</etudiant>\n";
	    }
    
	    return $expout;
    }


	 /**
     * Turns referentiel instance into an xml segment
     * @param referentiel instanceobject
     * @return string xml segment
     */

    function write_liste_etudiants( $referentiel_instance ) {
    	global $CFG;
        // initial string;
        $expout = "";
		if ($referentiel_instance){
			// ETUDIANTS
			if (isset($referentiel_instance->course) && ($referentiel_instance->course>0)){
				// ETUDIANTS
				$records_all_students = referentiel_get_students_course($referentiel_instance->course);
				if ($records_all_students){
					foreach ($records_all_students as $record){
						// USER
						if (isset($record->userid) && ($record->userid>0)){
							$record_etudiant = referentiel_get_etudiant_user($record->userid);
		    				if ($record_etudiant){
								$expout .= $this->write_etudiant($record_etudiant);
							}
						}
					}
				}
			}
        }
        return $expout;
    }
	
	function write_liste_etablissements() {
    	global $CFG;
        // initial string;
        $expout = ""; 
		// ETABLISSEMENTS
		$records_all_etablissements = referentiel_get_etablissements();
		if ($records_all_etablissements){
			foreach ($records_all_etablissements as $record){
				if ($record){
					$expout.=$this->write_etablissement($record);
				}
			}
        }
        return $expout;
    }

	
}	

?>
